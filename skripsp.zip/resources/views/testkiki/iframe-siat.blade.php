<!DOCTYPE HTML>
<html>
    <head>
        <title>Selamat Datang HTML</title>
    </head>
    <body>

        <p>Halo dunia!</p>

        <p>http://siat.ung.ac.id/index.php?mod=lapnilai&cmd=nilai/index&op=view&vtipe=print&vnim=531416066&vnidn=&vnilaidiambil=0&jvfak=05&vnama=&vnilaikosong=1&vnilaierror=1&jvjur=57401&vstatus=&vpenempatansemester=1&jvprodi=57201&vangkatan=2016&vtipetranskrip=0&vjenis=2&vtahun=2019&vsemester=2&vnumrow=</p>



        <p><b>Tulisan tebal</b>, <i>tulisan miring</i>, <u>tulisan bergaris bawah</u></p>


<br><br><br>


<iframe width="560" height="315" src="
http://siat.ung.ac.id/index.php?mod=lapnilai&cmd=nilai/index&op=view&vtipe=print&vnim=531416066&vnidn=&vnilaidiambil=0&jvfak=05&vnama=&vnilaikosong=1&vnilaierror=1&jvjur=57401&vstatus=&vpenempatansemester=1&jvprodi=57201&vangkatan=2016&vtipetranskrip=0&vjenis=2&vtahun=2019&vsemester=2&vnumrow=
" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<iframe width="560" height="315" src="https://www.youtube.com/embed/_kQN-3aNCeI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

    </body>
</html>
