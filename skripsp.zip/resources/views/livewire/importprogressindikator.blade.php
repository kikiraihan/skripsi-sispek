<div>


    {{ $progressimport }}


    <progress wire:poll.750ms max="100" wire:model="progressimport" class="w-100"></progress>



</div>
