<div class="container">
    




    <div>
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </div>





    <div class="row no-gutters mb-3 align-items-center">
        <div class="col-md-6 p-1">
            <div class="input-group">
                <div class="input-group-prepend ">
                  <div class="input-group-text border-right-0 bg-white" id="btnGroupAddon">
                    <i class="fas fa-search text-primary"></i>
                  </div>
                </div>
                <input type="text" wire:model.debounce.750ms="search" class="form-control border-left-0" placeholder="Cari nama atau nim">
            </div>
        </div>
        <div class="col-md-3 p-1">
            
        </div>

        <div class="col-md-3 p-1">
            <span class="float-md-right">
                
                <span class="small font-weight-bold"><i class="fas fa-users  fa-sm"></i> <?php echo e($jumlah_mahasiswa); ?></span>
                mahasiswa ditemukan
            </span>
        </div>
    </div>














    <?php if($mahasiswa->isEmpty()): ?>
        <div class="text-center  mt-5 mb-5">
            <img class="d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/fishing.svg')); ?>" alt="logout" width="35%">
            <h5>Mahasiswa</h5>
            <span class="text-secondary">tidak ditemukan</span>
            <br><br>
        </div>
    <?php else: ?>

    <div class="row">

        <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-lg-4 p-3" >
            <div class="card mb-4 h-100">

                <div class="card-body p-0 p-lg-3 text-lg-center row align-items-center no-gutters ">
                    <div class="col-lg-12 col-4">
                        <p><img class="rounded img-fluid " src="<?php echo e($m->user->gravatar); ?>" alt="card image"></p>
                    </div>
                    <div class="col-lg-12 col-8">
                        <h5 class="card-title"><?php echo e($m->nama); ?></h5>
                        
                        <p class="card-text d-md-block d-none">
                            <?php echo e($m->prodi); ?>, angkatan <?php echo e($m->angkatan); ?>

                            
                        </p>
                    </div>
                </div>



                <div class="card-footer p-0 pb-md-3 border-top-0 bg-white row no-gutters justify-content-center">
                    <div class="col-lg-6 p-2">
                        <a href="<?php echo e(route('mahasiswa.profil', ['id'=>$m->id])); ?>" class="font-weight-bold p-2 btn btn-primary btn-sm btn-block">Profil</a>
                    </div>
                    
                </div>

            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <?php echo e($mahasiswa->links()); ?>


    <?php endif; ?>




</div>
<?php /**PATH /Users/mohzulkiflikatili/1SiteKiki/skripsi/resources/views/livewire/mahasiswa/mahasiswapa.blade.php ENDPATH**/ ?>