<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mykegiatan', [])->dom;
} elseif ($_instance->childHasBeenRendered('biR80wQ')) {
    $componentId = $_instance->getRenderedChildComponentId('biR80wQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('biR80wQ');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('biR80wQ');
} else {
    $response = \Livewire\Livewire::mount('mykegiatan', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('biR80wQ', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('style-halaman'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-halaman'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kiki/1Sites/skripsi/resources/views/page/Datamahasiswa/mykegiatan.blade.php ENDPATH**/ ?>