<div>




    <div class="card shadow mb-4 overflow-hidden">
        <div class="card-header border-bottom-0 font-weight-bold text-primary ">Saudara</div>

        <div class="card-body px-0 py-0">
            <?php if($saudara->isEmpty()): ?>
            <div class="text-center  mt-5 mb-5">
                <img class="w-50 d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/gaming_.svg')); ?>" alt="logout">
                <span class="text-secondary">data saudara belum di isi</span>
                <br><br>
            </div>
            <?php else: ?>
                <div class="">
                    <table class="table table-striped mb-0">
                        <thead class="text-capitalize">
                          <tr>

                              <th>nama</th>
                              <th>pendidikan terakhir</th>
                              <th>bekerja</th>
                              <th>hubungan</th>
                              <th>aksi</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $saudara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($s->nama); ?></td>
                              <td><?php echo e($s->pendidikan_terakhir); ?></td>
                              <td><?php echo e($s->bekerjakah); ?></td>
                              <td><?php echo e($s->hubungan); ?></td>
                              <td>
                                <div class="dropdown no-arrow  dropleft">
                                  <a href="#" class="btn btn-sm btn-light" data-toggle="dropdown">
                                      ☰
                                  </a>
                                  <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                                    <a wire:click="bukaUpdate(<?php echo e($s->id); ?>)" data-toggle="modal" data-target="#modalInput"  class="dropdown-item "  href="#"><i class="fas fa-edit text-primary"></i> Edit </a>
                                    
                                    <a wire:click="$emit('swalAndaYakin','saudaraFixHapus',<?php echo e($s->id); ?>,'Anda akan menghapus data tersebut!')"  class="dropdown-item "  href="#"><i class="fas fa-trash text-danger"></i> Hapus </a>
                                  </div>
                                </div>
                              </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>


        </div>

        <button wire:click="bukaTambah()" type="button" data-toggle="modal" data-target="#modalInput" href="#" class="btn btn-block btn-light rounded-0 ">Tambah data <i class="fas fa-plus "></i></button>

    </div>






</div>
<?php /**PATH C:\Users\Asus\Documents\1SiteKiki\skripsi\resources\views/livewire/mysaudara.blade.php ENDPATH**/ ?>