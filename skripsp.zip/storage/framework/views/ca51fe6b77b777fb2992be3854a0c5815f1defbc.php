<?php $__env->startSection($section); ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount($component, $componentParameters)->dom;
} elseif ($_instance->childHasBeenRendered('8NsA2VG')) {
    $componentId = $_instance->getRenderedChildComponentId('8NsA2VG');
    $componentTag = $_instance->getRenderedChildComponentTagName('8NsA2VG');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8NsA2VG');
} else {
    $response = \Livewire\Livewire::mount($component, $componentParameters);
    $dom = $response->dom;
    $_instance->logRenderedChild('8NsA2VG', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kiki/1Sites/skripsi/vendor/livewire/livewire/src/Macros/livewire-view.blade.php ENDPATH**/ ?>