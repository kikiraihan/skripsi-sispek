<div>


    <?php echo e($progressimport); ?>



    <progress max="100" wire:model="progressimport" class="w-100"></progress>



</div>
<?php /**PATH /home/kiki/1Sites/skripsi/resources/views/livewire/importprogressindikator.blade.php ENDPATH**/ ?>