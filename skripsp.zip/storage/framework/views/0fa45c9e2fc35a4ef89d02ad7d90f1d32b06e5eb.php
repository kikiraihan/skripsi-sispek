<?php $__env->startSection('content'); ?>

<div class="row mb-4">
    <div class="col-md-3 order-md-2 text-right mb-5">


        <div class="text-center ">
            <img src="<?php echo e($user->gravatar); ?>" class="shadow-sm rounded-circle">
            <br><br>
            <a class="btn btn-success " href="https://id.gravatar.com/">
                <i class="fas fa-user-circle fa-sm fa-fw "></i>
                Ganti foto
            </a>
        </div>
        <hr>

        <?php echo $__env->make('page.Datamahasiswa.updatePassword', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    <div class="col-md-9 order-md-1">
        <div class="card shadow mb-4 overflow-hidden">
            <div class="card-header text-left bg-white border-0">
                <b>Biodata</b>
                <small class="float-right text-info">*tap untuk mengedit</small>
            </div>

                <form action="<?php echo e(route('biodata.my.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <ul class="list-group list-group-flush">

                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">Dosen Pembimbing Akademik : </span>
                            <select name="id_dosen_pa" class="
                            <?php $__errorArgs = ['id_dosen_pa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            text-right form-control form-control-sm form-control-plaintext d-inline w-50 text-capitalize <?php echo e($errors->has('id_dosen_pa') ? ' is-invalid' : ''); ?>

                            " >
                                <option  <?php echo e(old('id_dosen_pa',$user->mahasiswa->id_dosen_pa )==null?"selected":""); ?> value="0">-</option>
                                <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option  <?php echo e(old('id_dosen_pa',$user->mahasiswa->id_dosen_pa )==$d->id?"selected":""); ?> value="<?php echo e($d->id); ?>"><?php echo e($d->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['id_dosen_pa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>


                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">Nama : </span>
                            <input type="text" placeholder="nama" name="nama" value="<?php echo e($user->mahasiswa->nama); ?>" class="<?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-right form-control form-control-sm form-control-plaintext d-inline w-50" >
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">NIM : </span>
                            <input disabled type="text" placeholder="nim" name="nim" value="<?php echo e($user->mahasiswa->nim); ?>" class="<?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-right form-control form-control-sm form-control-plaintext d-inline w-50" >
                            <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">Tempat Lahir : </span>
                            <input type="text" placeholder="tempat_lahir" name="tempat_lahir" value="<?php echo e($user->mahasiswa->tempat_lahir); ?>" class="<?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-right form-control form-control-sm form-control-plaintext d-inline w-50" >
                            <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">Tanggal Lahir : </span>
                            <input type="date" placeholder="tgl_lahir" name="tgl_lahir" value="<?php echo e($user->mahasiswa->tgl_lahir->formatLocalized("%Y-%m-%d")); ?>" class="<?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-right form-control form-control-sm form-control-plaintext d-inline w-50" >
                            <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">Jenis Kelamin : </span>
                            <select name="jenis_kelamin" class="
                            <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            text-right form-control form-control-sm form-control-plaintext d-inline w-50 text-capitalize <?php echo e($errors->has('jenis_kelamin') ? ' is-invalid' : ''); ?>

                            " >
                                <option  value="" selected="selected" disabled="disabled" hidden="hidden">-</option>
                                <option  <?php echo e(old('jenis_kelamin',$user->mahasiswa->jenis_kelamin )=="Laki-Laki"?"selected":""); ?> value="Laki-Laki">Laki-Laki</option>
                                <option  <?php echo e(old('jenis_kelamin',$user->mahasiswa->jenis_kelamin )=="Perempuan"?"selected":""); ?> value="Perempuan">Perempuan</option>
                            </select>
                            <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">Golongan Darah : </span>
                            <select name="golongan_darah" class="
                            <?php $__errorArgs = ['golongan_darah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            text-right form-control form-control-sm form-control-plaintext d-inline w-50 text-capitalize <?php echo e($errors->has('golongan_darah') ? ' is-invalid' : ''); ?>

                            " >
                                <option  value="" selected="selected" disabled="disabled" hidden="hidden">-</option>
                                <option  <?php echo e(old('golongan_darah',$user->mahasiswa->golongan_darah )=="O"?"selected":""); ?> value="O">O</option>
                                <option  <?php echo e(old('golongan_darah',$user->mahasiswa->golongan_darah )=="A"?"selected":""); ?> value="A">A</option>
                                <option  <?php echo e(old('golongan_darah',$user->mahasiswa->golongan_darah )=="A+"?"selected":""); ?> value="A+">A+</option>
                                <option  <?php echo e(old('golongan_darah',$user->mahasiswa->golongan_darah )=="B"?"selected":""); ?> value="B">B</option>
                                <option  <?php echo e(old('golongan_darah',$user->mahasiswa->golongan_darah )=="B+"?"selected":""); ?> value="B+">B+</option>
                                <option  <?php echo e(old('golongan_darah',$user->mahasiswa->golongan_darah )=="AB"?"selected":""); ?> value="AB">AB</option>
                            </select>
                            <?php $__errorArgs = ['golongan_darah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">Agama : </span>
                            <select name="agama" class="
                            <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            text-right form-control form-control-sm form-control-plaintext d-inline w-50 text-capitalize <?php echo e($errors->has('agama') ? ' is-invalid' : ''); ?>

                            " >
                                <option  value="" selected="selected" disabled="disabled" hidden="hidden">-</option>
                                <option  <?php echo e(old('agama',$user->mahasiswa->agama )=="Islam"?"selected":""); ?> value="Islam">Islam</option>
                                <option  <?php echo e(old('agama',$user->mahasiswa->agama )=="Hindu"?"selected":""); ?> value="Hindu">Hindu</option>
                                <option  <?php echo e(old('agama',$user->mahasiswa->agama )=="Kristen"?"selected":""); ?> value="Kristen">Kristen</option>
                                <option  <?php echo e(old('agama',$user->mahasiswa->agama )=="Katolik"?"selected":""); ?> value="Katolik">Katolik</option>
                                <option  <?php echo e(old('agama',$user->mahasiswa->agama )=="Konghuchu"?"selected":""); ?> value="Konghuchu">Konghuchu</option>
                                <option  <?php echo e(old('agama',$user->mahasiswa->agama )=="Budha"?"selected":""); ?> value="Budha">Budha</option>
                                <option  <?php echo e(old('agama',$user->mahasiswa->agama )=="Lainnya"?"selected":""); ?> value="Lainnya">Lainnya</option>
                            </select>
                            <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">Status Kawin : </span>
                            <select name="status_menikah" class="
                            <?php $__errorArgs = ['status_menikah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            text-right form-control form-control-sm form-control-plaintext d-inline w-50 text-capitalize <?php echo e($errors->has('status_menikah') ? ' is-invalid' : ''); ?>

                            " >
                                <option  value="" selected="selected" disabled="disabled" hidden="hidden">-</option>
                                <option  <?php echo e(old('status_menikah',$user->mahasiswa->status_menikah )=="1"?"selected":""); ?> value="1">Sudah Menikah</option>
                                <option  <?php echo e(old('status_menikah',$user->mahasiswa->status_menikah )=="0"?"selected":""); ?> value="0">Belum Menikah</option>
                            </select>
                            <?php $__errorArgs = ['status_menikah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>

                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">Email : </span>
                            <input type="email" placeholder="email" name="email" value="<?php echo e($user->email); ?>" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-right form-control form-control-sm form-control-plaintext d-inline w-50" >
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">No KTP : </span>
                            <input type="text" placeholder="no_ktp" name="no_ktp" value="<?php echo e($user->mahasiswa->no_ktp); ?>" class="<?php $__errorArgs = ['no_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-right form-control form-control-sm form-control-plaintext d-inline w-50" >
                            <?php $__errorArgs = ['no_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">No HP : </span>
                            <input type="text" placeholder="no_hp" name="no_hp" value="<?php echo e($user->mahasiswa->no_hp); ?>" class="<?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-right form-control form-control-sm form-control-plaintext d-inline w-50" >
                            <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>

                        <li class="list-group-item text-right align-items-center">
                            <span class="float-left small">Asuransi : </span>
                            <select name="asuransi" class="
                            <?php $__errorArgs = ['asuransi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            text-right form-control form-control-sm form-control-plaintext d-inline w-50 text-capitalize <?php echo e($errors->has('asuransi') ? ' is-invalid' : ''); ?>

                            " >
                                <option  <?php echo e(old('asuransi',$user->mahasiswa->asuransi )=="-"?"selected":""); ?> value="-">-</option>
                                <option  <?php echo e(old('asuransi',$user->mahasiswa->asuransi )=="JAMKESMAS"?"selected":""); ?> value="JAMKESMAS">JAMKESMAS</option>
                                <option  <?php echo e(old('asuransi',$user->mahasiswa->asuransi )=="JAMKESMAN"?"selected":""); ?> value="JAMKESMAN">JAMKESMAN</option>
                                <option  <?php echo e(old('asuransi',$user->mahasiswa->asuransi )=="JAMKESDA"?"selected":""); ?> value="JAMKESDA">JAMKESDA</option>
                                <option  <?php echo e(old('asuransi',$user->mahasiswa->asuransi )=="BPJS"?"selected":""); ?> value="BPJS">BPJS</option>
                                <option  <?php echo e(old('asuransi',$user->mahasiswa->asuransi )=="JAMKESTA"?"selected":""); ?> value="JAMKESTA">JAMKESTA</option>
                                <option  <?php echo e(old('asuransi',$user->mahasiswa->asuransi )=="Kelurga Sejahtera (KKS)"?"selected":""); ?> value="Kelurga Sejahtera (KKS)">Kelurga Sejahtera (KKS)</option>
                                <option  <?php echo e(old('asuransi',$user->mahasiswa->asuransi )=="Program Keluarga Harapan (PKH)"?"selected":""); ?> value="Program Keluarga Harapan (PKH)">Program Keluarga Harapan (PKH)</option>
                            </select>
                            <?php $__errorArgs = ['asuransi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>



                        
                        <li class="list-group-item text-right align-items-center"><span class="float-left small">Alamat Sekarang : </span>
                            <?php
                            $alamat_sekarang=$user->mahasiswa->lokasi->where('jenis','alamat_sekarang')->first();
                            ?>
                            <?php if($alamat_sekarang==NULL): ?>
                            -
                            <?php else: ?>
                            <?php echo e($alamat_sekarang->deskripsi); ?>

                            <?php endif; ?>
                        </li>
                        <li class="list-group-item text-right align-items-center"><span class="float-left small">Alamat Asal : </span>
                            <?php
                            $alamat_asal=$user->mahasiswa->lokasi->where('jenis','alamat_asal')->first();
                            ?>
                            <?php if($alamat_asal==NULL): ?>
                            -
                            <?php else: ?>
                            <?php echo e($alamat_asal->deskripsi); ?>

                            <?php endif; ?>
                        </li>

                        <li class="list-group-item text-right align-items-center"><span class="float-left small">Minat/Bakat : </span>
                            <?php if($user->mahasiswa->minatbakat->isEmpty()): ?>
                            -
                            <?php else: ?>
                            <?php $__currentLoopData = $user->mahasiswa->minatbakat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($item); ?>,<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </li>

                        <li class="list-group-item text-right align-items-center">
                            <button type="submit" class="btn btn-block btn-success btn-lg">Simpan perubahan</button>
                        </li>


                    </ul>
                </form>


        </div>

    </div>
</div>






<?php $__env->stopSection(); ?>



<?php $__env->startSection('style-halaman'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-halaman'); ?>

<?php if(session('success')): ?>
<script>
    Swal.fire({
        //toast: true,
        //position: 'top-end',
        showConfirmButton: false,
        timer: 1500,
        timerProgressBar: false,
        //onOpen: (toast) => {
          //toast.addEventListener('mouseenter', Swal.stopTimer)
          //toast.addEventListener('mouseleave', Swal.resumeTimer)
        //},
        icon: 'success',
        title: "Berhasil" ,
        text: 'biodata berhasil diupdate!',
    });
</script>
<?php elseif(session('successGantiPassword')): ?>
<script>
    Swal.fire({
        //toast: true,
        //position: 'top-end',
        showConfirmButton: false,
        timer: 1500,
        timerProgressBar: false,
        //onOpen: (toast) => {
          //toast.addEventListener('mouseenter', Swal.stopTimer)
          //toast.addEventListener('mouseleave', Swal.resumeTimer)
        //},
        icon: 'success',
        title: "Berhasil" ,
        text: 'password berhasil diupdate!!',
    });
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Documents\1SiteKiki\skripsi\resources\views/page/Datamahasiswa/editBio.blade.php ENDPATH**/ ?>