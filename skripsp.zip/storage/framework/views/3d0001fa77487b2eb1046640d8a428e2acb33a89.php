<?php $__env->startSection('content'); ?>



    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('rekomendasi.masterpreferensiinput', [])->dom;
} elseif ($_instance->childHasBeenRendered('SfH1HrL')) {
    $componentId = $_instance->getRenderedChildComponentId('SfH1HrL');
    $componentTag = $_instance->getRenderedChildComponentTagName('SfH1HrL');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SfH1HrL');
} else {
    $response = \Livewire\Livewire::mount('rekomendasi.masterpreferensiinput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('SfH1HrL', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>





<?php $__env->stopSection(); ?>



<?php $__env->startSection('style-halaman'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-halaman'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="<?php echo e(asset('assets_kiki/form_kriteria.js')); ?>"></script>

    <script>

        window.livewire.on('swalInputMatriks', (baris,kolom,barisTitle,kolomTitle, valueSebelumnya) => {
          Swal.fire({
            title: ' <small class="mr-2">'+kolomTitle+' <br>(ke kiri)</small> <br>atau<br> <small class="ml-2">'+barisTitle+' <br>(ke kanan)</small>',
            icon: 'question',
            input: 'range',
            inputAttributes: {
                min: -9,
                max: 9,
                step: 1
            },
            inputValue: valueSebelumnya,
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Simpan'
          }).then((result) => {

            if(result.value)
            {
                if(result.value % 1 != 0)
                result.value=0;

                window.livewire.emit('setMatriksKriteria',baris,kolom,result.value);
            }

          });
        })




        window.livewire.on('swalAlertDanger', (title, pesan) => {
            Swal.fire({
                //toast: true,
                //position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                onOpen: (toast) => {
                  toast.addEventListener('mouseenter', Swal.stopTimer)
                  toast.addEventListener('mouseleave', Swal.resumeTimer)
                },
                icon: 'error',
                title: title ,
                text: pesan,
            });
        })

        window.livewire.on('swalAlertSuccess', (title, pesan) => {
            Swal.fire({
                //toast: true,
                //position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                onOpen: (toast) => {
                  toast.addEventListener('mouseenter', Swal.stopTimer)
                  toast.addEventListener('mouseleave', Swal.resumeTimer)
                },
                icon: 'success',
                title: title ,
                text: pesan,
            });
        })


      </script>
<?php $__env->stopSection(); ?>















    
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kiki/1Sites/skripsi/resources/views/page/Preference/tambah.blade.php ENDPATH**/ ?>