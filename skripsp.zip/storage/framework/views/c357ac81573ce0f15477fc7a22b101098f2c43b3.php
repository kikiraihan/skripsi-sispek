<?php $__env->startSection('content'); ?>



<?php if($komponen=="masterpreferensi.index"): ?>
<?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('rekomendasi.masterpreferensi', [])->dom;
} elseif ($_instance->childHasBeenRendered('UZVrKBr')) {
    $componentId = $_instance->getRenderedChildComponentId('UZVrKBr');
    $componentTag = $_instance->getRenderedChildComponentTagName('UZVrKBr');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UZVrKBr');
} else {
    $response = \Livewire\Livewire::mount('rekomendasi.masterpreferensi', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('UZVrKBr', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>


<?php elseif($komponen=="masterpreferensi.input"): ?>
<?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('rekomendasi.masterpreferensiinput', [])->dom;
} elseif ($_instance->childHasBeenRendered('ts2lYQn')) {
    $componentId = $_instance->getRenderedChildComponentId('ts2lYQn');
    $componentTag = $_instance->getRenderedChildComponentTagName('ts2lYQn');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ts2lYQn');
} else {
    $response = \Livewire\Livewire::mount('rekomendasi.masterpreferensiinput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('ts2lYQn', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

<?php elseif($komponen=="rekomendasiotomatis.index"): ?>
<?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('rekomendasi.rekomendasiotomatis', [])->dom;
} elseif ($_instance->childHasBeenRendered('rtqqUfu')) {
    $componentId = $_instance->getRenderedChildComponentId('rtqqUfu');
    $componentTag = $_instance->getRenderedChildComponentTagName('rtqqUfu');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rtqqUfu');
} else {
    $response = \Livewire\Livewire::mount('rekomendasi.rekomendasiotomatis', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('rtqqUfu', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

<?php endif; ?>






<?php $__env->stopSection(); ?>



<?php $__env->startSection('style-halaman'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

    <style>
        table tbody tr th{
            text-align: center;
            width: 1em;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-halaman'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="<?php echo e(asset('assets_kiki/form_kriteria.js')); ?>"></script>

    <script>

        window.livewire.on('swalInputMatriks', (baris,kolom,barisTitle,kolomTitle, valueSebelumnya) => {
          Swal.fire({
            title: ' <small class="mr-2">'+kolomTitle+' <br>(ke kiri)</small> <br>atau<br> <small class="ml-2">'+barisTitle+' <br>(ke kanan)</small>',
            icon: 'question',
            input: 'range',
            inputAttributes: {
                min: -9,
                max: 9,
                step: 1
            },
            inputValue: valueSebelumnya,
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Simpan'
          }).then((result) => {

            if(result.value)
            {
                if(result.value % 1 != 0)
                result.value=0;

                window.livewire.emit('setMatriksKriteria',baris,kolom,result.value);
            }

          });
        })




        window.livewire.on('swalAlertDanger', (title, pesan) => {
            Swal.fire({
                //toast: true,
                //position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                onOpen: (toast) => {
                  toast.addEventListener('mouseenter', Swal.stopTimer)
                  toast.addEventListener('mouseleave', Swal.resumeTimer)
                },
                icon: 'error',
                title: title ,
                text: pesan,
            });
        })

        window.livewire.on('swalAlertSuccess', (title, pesan) => {
            Swal.fire({
                //toast: true,
                //position: 'top-end',
                showConfirmButton: false,
                timer: 1000,
                timerProgressBar: false,
                //onOpen: (toast) => {
                  //toast.addEventListener('mouseenter', Swal.stopTimer)
                  //toast.addEventListener('mouseleave', Swal.resumeTimer)
                //},
                icon: 'success',
                title: title ,
                text: pesan,
            });
        })





        window.livewire.on('swalDeleted', (tujuan,idhapus) => {
            Swal.fire({
              title: 'Anda yakin?',
              text: "Anda akan menghapus data tersebut!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Ya, hapus!'
            }).then((result) => {
              if (result.value) {

                window.livewire.emit(tujuan,idhapus);

                Swal.fire(
                  'Terhapus!',
                  'data telah dihapus.',
                  'success'
                )

              }
            });
          })


      </script>
<?php $__env->stopSection(); ?>















    
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kiki/1Sites/skripsi/resources/views/page/Rekomendasi/master.blade.php ENDPATH**/ ?>