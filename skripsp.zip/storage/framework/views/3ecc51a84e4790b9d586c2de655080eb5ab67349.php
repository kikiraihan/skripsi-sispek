

<div>

    <h5 class="text-primary">Kriteria</h5>
    






    <div class="row no-gutters mb-3">
        <div class="col-md-6 p-1">
            <div class="input-group">
                <div class="input-group-prepend ">
                  <div class="input-group-text border-right-0 bg-white" id="btnGroupAddon">
                    <i class="fas fa-search text-primary"></i>
                  </div>
                </div>
                <input type="text" wire:model.debounce.750ms="search" class="form-control border-left-0" placeholder="Cari title">
            </div>
        </div>
        <div class="col-md-3 p-1">

            <?php if(Auth::user()->hasRole('Admin|Super Admin')): ?>
            <a href="#" wire:loading.attr="disabled" wire:click="ImportNilaiMK" class="btn btn-primary">
                <div wire:loading.remove wire:target="ImportNilaiMK">
                    
                    <span class="font-weight-bold">Import dari Nilai MK</span>
                    <i class="fas fa-plus fa-md"></i>
                </div>
                <div wire:loading wire:target="ImportNilaiMK" >
                    <span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>
                    Mengimport..
                </div>
            </a>
            <?php endif; ?>

        </div>

        <div class="col-md-3 p-1">
            <span class="float-md-right">
                <?php echo e($jlh_kriteria); ?>

                ditemukan
                <?php if($kriteria_nilai_mk!=0): ?>
                (
                <span class="small font-weight-bold"><?php echo e($kriteria_nilai_mk); ?></span>
                nilai mk
                )
                <?php endif; ?>
            </span>
        </div>

        <div class="custom-control custom-checkbox mt-3 ml-2">
            <input wire:model="tampilnilai" type="checkbox" class="custom-control-input" id="customCheck1">
            <label class="custom-control-label" for="customCheck1">Tampilkan kriteria nilai matakuliah</label>
        </div>

    </div>











    <div class="card shadow-sm mb-4 overflow-hidden">


        <div class="card-body px-0 py-0">
            <?php if($kriteria->isEmpty()): ?>
            <div class="text-center  mt-5 mb-5">
              <img class="d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/fishing.svg')); ?>" alt="logout" width="35%">
              <h5>Kriteria</h5>
              <span class="text-secondary">tidak ditemukan</span>
              <br><br>
            </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped mb-0">
                        <thead class="text-capitalize">
                          <tr>
                              
                              <th>Title</th>
                              <th>Model Type</th>
                              <?php if(Auth::user()->hasRole('Admin|Super Admin')): ?>
                              <th class="d-none d-md-table-cell">Path To</th>
                              <?php endif; ?>
                              <th class="d-none d-md-table-cell">Jenis</th>
                              <th class="d-none d-md-table-cell">Rasio</th>
                              <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($p->title); ?></td>
                              <td><?php echo e(str_replace('App\Models','',$p->model_type)); ?></td>
                              <?php if(Auth::user()->hasRole('Admin|Super Admin')): ?>
                              <td class="d-none d-md-table-cell">
                                  <?php $__currentLoopData = $p->PathToRenderArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path=>$isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="badge badge-info">
                                    <?php echo e($path); ?>

                                    <?php if($isi!=null): ?>
                                    (<?php $__currentLoopData = $isi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($i); ?>, <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>)
                                    <?php endif; ?>
                                  </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <?php endif; ?>
                              <td class="d-none d-md-table-cell"><?php echo e($p->jenis); ?></td>
                              <td class="d-none d-md-table-cell">
                                  <?php if($p->rasio!=null): ?>
                                  <?php $__currentLoopData = $p->rasioRenderArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path=>$isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="badge badge-primary">
                                      "<?php echo e($path); ?>" - <span class="font-weight-bold"><?php echo e($isi); ?></span>
                                  </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php else: ?>
                                  kosong
                                  <?php endif; ?>
                                </td>
                              <td>
                                <div class="dropdown no-arrow position-absolute dropleft">
                                  <span class="btn btn-sm btn-light" data-toggle="dropdown">
                                      ☰
                                  </span>
                                  <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">

                                    <?php if(Auth::user()->hasRole('Admin|Super Admin')): ?>
                                    <a wire:click="bukaUpdate(<?php echo e($p->id); ?>)" data-toggle="modal" data-target="#modalInput"  class="dropdown-item "  href="#"><i class="fas fa-edit text-primary"></i> Edit </a>
                                    
                                    <a wire:click="$emit('swalDeleted','kriteriaFixHapus',<?php echo e($p->id); ?>)"  class="dropdown-item "  href="#"><i class="fas fa-trash text-danger"></i> Hapus </a>
                                    <?php else: ?>
                                    <span class="dropdown-item">-Tidak Tersedia-</span>
                                    <?php endif; ?>

                                  </div>

                                </div>
                              </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>


        </div>

        <?php if(Auth::user()->hasRole('Admin|Super Admin')): ?>
        <button wire:click="bukaTambah()" type="button" data-toggle="modal" data-target="#modalInput" href="#" class="btn btn-block btn-light rounded-0 ">Kriteria baru <i class="fas fa-plus "></i></button>
        <?php endif; ?>
    </div>

    <?php echo e($kriteria->links()); ?>











</div>


















































    <?php /**PATH /Users/mohzulkiflikatili/1SiteKiki/skripsi/resources/views/livewire/rekomendasi/masterkriteria.blade.php ENDPATH**/ ?>