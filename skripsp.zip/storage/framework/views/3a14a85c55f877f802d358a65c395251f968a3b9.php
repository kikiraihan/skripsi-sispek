<?php $__env->startSection('content'); ?>


  <div class="card shadow mb-4 overflow-hidden">
      <div class="card-header border-bottom-0 font-weight-bold text-primary ">Saudara</div>

      <div class="card-body px-0 py-0">
          <?php if($user->mahasiswa->saudara->isEmpty()): ?>
          <div class="text-center  mt-5 mb-5">
              <img class="w-50 d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/gaming_.svg')); ?>" alt="logout">
              <span class="text-secondary">data saudara belum di isi</span>
              <br><br>
          </div>
          <?php else: ?>
              <div class="table-responsive">
                  <table class="table table-striped mb-0">
                      <thead class="text-capitalize">
                        <tr>

                            <th>nama</th>
                            <th>pendidikan terakhir</th>
                            <th>bekerja</th>
                            <th>hubungan</th>
                            <th>aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $user->mahasiswa->saudara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($o->nama); ?></td>
                            <td><?php echo e($o->pendidikan_terakhir); ?></td>
                            <td><?php echo e($o->bekerjakah); ?></td>
                            <td><?php echo e($o->hubungan); ?></td>
                            <td><a href="#"><i class="icon-plus text-muted"></i>add</a></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
          <?php endif; ?>


      </div>

      <a href="#" class="btn btn-block btn-light rounded-0 ">Tambahkan <i class="fas fa-plus "></i></a>

  </div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('style-halaman'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-halaman'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kiki/1Sites/skripsi/resources/views/page/Datamahasiswa/mysaudara.blade.php ENDPATH**/ ?>