<div>





    <div class="card shadow mb-4 overflow-hidden">
        <div class="card-header border-bottom-0 font-weight-bold text-primary ">User Management</div>



        <div class="card-body px-0 py-0">
            <?php if($admin->isEmpty()): ?>
            
            <?php else: ?>
            <br>
                <label class="ml-3 font-weight-bold small">Admin</label>
                <label class="mr-3 font-weight-bold float-right small"><i class="fas fa-users"></i> <?php echo e($admin->count()); ?> ditemukan</label>
                
                <div class="table-responsive">
                    <table class="table table-striped mb-0">
                        <thead class="text-capitalize">
                        <tr>
                            <th>Username</th>
                            <th>Role</th>
                            <th>Email</th>
                            <th width="20px">Aksi</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $or): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($or->username); ?></td>
                            <td>
                                <?php $__currentLoopData = json_decode($or->roles->pluck('name')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge <?php if($item=='Kaprodi' OR $item=='Kajur'): ?> badge-success <?php else: ?> badge-info <?php endif; ?>"><?php echo e($item); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($or->email); ?></td>
                            <td >
                                <div class="dropdown no-arrow position-absolute dropleft">
                                    <a href="#" class="btn btn-sm btn-light" data-toggle="dropdown">
                                        ☰
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                                        <span style=" cursor: pointer;" wire:click="bukaUpdate(<?php echo e($or->id); ?>)" data-toggle="modal" data-target="#modalInput"  class="dropdown-item "  href="#"><i class="fas fa-edit text-primary"></i> Edit </span>
                                        
                                        <span style=" cursor: pointer;" wire:click="$emit('swalAndaYakin','adminDosenFixHapus',<?php echo e($or->id); ?>,'Anda akan menghapus data tersebut!')"  class="dropdown-item "  href="#"><i class="fas fa-trash text-danger"></i> Hapus </span>
                                        <span style=" cursor: pointer;" wire:click="$emit('swalAndaYakin','adminDosenResetPassword',<?php echo e($or->id); ?>,'Reset password user ini menjadi `password`?')"
                                            class="dropdown-item "  href="#"><i class="fas fa-redo-alt text-secondary"></i> Reset password </span>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <br><br><br>
            <?php endif; ?>


        </div>


        <div class="card-body px-0 py-0">
            <?php if($dosen->isEmpty()): ?>
            <div class="text-center  mt-5 mb-5">
                <img class="w-50 d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/startup_.svg')); ?>" alt="logout">
                <h5>User (Dosen,Admin)</h5>
                <span class="text-secondary">belum ada data ormawa yang di ikuti</span>
              <br><br>
            </div>
            <?php else: ?>
            <label class="ml-3 font-weight-bold small">Dosen, Kajur, dan Kaprodi</label>
            <label class="mr-3 font-weight-bold float-right small"><i class="fas fa-users"></i> <?php echo e($dosen->count()); ?> ditemukan</label>
                <div class="table-responsive">
                    <table class="table table-striped mb-0">
                        <thead class="text-capitalize">
                        <tr>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Kredensial Role</th>
                            <th width="20px">Aksi</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $or): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($or->dosen->nama); ?></td>
                            <td><?php echo e($or->email); ?></td>
                            <td>
                                <?php $__currentLoopData = json_decode($or->roles->pluck('name')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge <?php if($item=='Kaprodi' OR $item=='Kajur'): ?> badge-success <?php else: ?> badge-info <?php endif; ?>"><?php echo e($item); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php if($or->hasRole('Dosen')): ?>
                                    
                                    <sup>Username  :</sup> <span class="float-right"><?php echo e($or->username); ?></span>
                                    <br>
                                    <sup>NIP  :</sup> <span class="float-right"><?php echo e($or->dosen->nip); ?></span>
                                <?php endif; ?>
                                <?php if($or->hasRole('Kaprodi')): ?>
                                    <br>
                                    <sup>Prodi  :</sup> <span class="float-right"><?php echo e($or->dosen->kaprodi->prodi); ?></span>
                                    <br>
                                    <sup>Periode  :</sup> <span class="float-right"><?php echo e($or->dosen->kaprodi->periode); ?></span>
                                <?php endif; ?>
                                <?php if($or->hasRole('Kajur')): ?>
                                <br>
                                <sup>Jurusan  :</sup> <span class="float-right"><?php echo e($or->dosen->kajur->jurusan); ?></span>
                                <br>
                                <sup>Periode  :</sup> <span class="float-right"><?php echo e($or->dosen->kajur->periode); ?></span>
                                <?php endif; ?>


                            </td>

                            <td>
                                <div class="dropdown no-arrow position-absolute dropleft">
                                    <a href="#" class="btn btn-sm btn-light" data-toggle="dropdown">
                                        ☰
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                                        

                                        <span style=" cursor: pointer;" wire:click="bukaUpdate(<?php echo e($or->id); ?>)" data-toggle="modal" data-target="#modalInput"  class="dropdown-item "  ><i class="fas fa-edit text-primary"></i> Edit </span>
                                        <span style=" cursor: pointer;" wire:click="$emit('swalAndaYakin','adminDosenFixHapus',<?php echo e($or->id); ?>,'Anda akan menghapus data tersebut!')"  class="dropdown-item "  ><i class="fas fa-trash text-danger"></i> Hapus </span>
                                        <span style=" cursor: pointer;" wire:click="$emit('swalAndaYakin','adminDosenResetPassword',<?php echo e($or->id); ?>,'Anda akan mereset password menjadi `Password` user ini')"
                                        class="dropdown-item "  ><i class="fas fa-redo-alt text-secondary"></i> Reset password </span>

                                        <?php if($or->hasRole('Kaprodi')): ?>
                                        <div class="dropdown-divider"></div>
                                        <span style=" cursor: pointer;" wire:click=
                                        "$emit('swalAndaYakin','adminDosenBatalkanKaprodi',<?php echo e($or->id); ?>,'Anda akan membatalkan role kaprodi user ini')"
                                        class="dropdown-item "  ><i class="fas fa-ban text-danger"></i> Batalkan Kaprodi </span>
                                        <?php elseif($or->hasRole('Kajur')): ?>
                                        <div class="dropdown-divider"></div>
                                        <span style=" cursor: pointer;" wire:click=
                                        "$emit('swalAndaYakin','adminDosenBatalkanKajur',<?php echo e($or->id); ?>,'Anda akan membatalkan role kajur user ini')"
                                        class="dropdown-item "  ><i class="fas fa-ban text-danger"></i> Batalkan Kajur </span>
                                        <?php else: ?>
                                            <?php if($or->hasRole('Dosen')): ?>
                                            <div class="dropdown-divider"></div>
                                            <span style=" cursor: pointer;" wire:click="bukaSetAsKajur(<?php echo e($or->id); ?>)" data-toggle="modal" data-target="#modalInput"  class="dropdown-item "  ><i class="fas fa-user-edit text-success"></i> Set Kajur </span>
                                            <span style=" cursor: pointer;" wire:click="bukaSetAsKaprodi(<?php echo e($or->id); ?>)" data-toggle="modal" data-target="#modalInput"  class="dropdown-item "  ><i class="fas fa-user-edit text-success"></i> Set Kaprodi </span>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>


        </div>

        <button wire:click="bukaTambah()" type="button" data-toggle="modal" data-target="#modalInput" href="#" class="btn btn-block btn-light rounded-0 ">Baru <i class="fas fa-plus "></i></button>
    </div>











</div>
<?php /**PATH C:\Users\Asus\Documents\1SiteKiki\skripsi\resources\views/livewire/master/admindosen.blade.php ENDPATH**/ ?>