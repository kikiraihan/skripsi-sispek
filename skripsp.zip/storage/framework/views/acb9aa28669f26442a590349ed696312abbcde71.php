<?php $__env->startSection('content'); ?>



<?php if($komponen=="index"): ?>
<?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('rekomendasi.masterpreferensi', [])->dom;
} elseif ($_instance->childHasBeenRendered('GgGZdZd')) {
    $componentId = $_instance->getRenderedChildComponentId('GgGZdZd');
    $componentTag = $_instance->getRenderedChildComponentTagName('GgGZdZd');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GgGZdZd');
} else {
    $response = \Livewire\Livewire::mount('rekomendasi.masterpreferensi', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('GgGZdZd', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
<?php elseif($komponen=="input"): ?>
<?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('rekomendasi.masterpreferensiinput', [])->dom;
} elseif ($_instance->childHasBeenRendered('p0Wiv3B')) {
    $componentId = $_instance->getRenderedChildComponentId('p0Wiv3B');
    $componentTag = $_instance->getRenderedChildComponentTagName('p0Wiv3B');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('p0Wiv3B');
} else {
    $response = \Livewire\Livewire::mount('rekomendasi.masterpreferensiinput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('p0Wiv3B', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
<?php endif; ?>






<?php $__env->stopSection(); ?>



<?php $__env->startSection('style-halaman'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

    <style>
        table tbody tr th{
            text-align: center;
            width: 1em;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-halaman'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="<?php echo e(asset('assets_kiki/form_kriteria.js')); ?>"></script>

    <script>

        window.livewire.on('swalInputMatriks', (baris,kolom,barisTitle,kolomTitle, valueSebelumnya) => {
          Swal.fire({
            title: ' <small class="mr-2">'+kolomTitle+' <br>(ke kiri)</small> <br>atau<br> <small class="ml-2">'+barisTitle+' <br>(ke kanan)</small>',
            icon: 'question',
            input: 'range',
            inputAttributes: {
                min: -9,
                max: 9,
                step: 1
            },
            inputValue: valueSebelumnya,
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Simpan'
          }).then((result) => {

            if(result.value)
            {
                if(result.value % 1 != 0)
                result.value=0;

                window.livewire.emit('setMatriksKriteria',baris,kolom,result.value);
            }

          });
        })




        window.livewire.on('swalAlertDanger', (title, pesan) => {
            Swal.fire({
                //toast: true,
                //position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                onOpen: (toast) => {
                  toast.addEventListener('mouseenter', Swal.stopTimer)
                  toast.addEventListener('mouseleave', Swal.resumeTimer)
                },
                icon: 'error',
                title: title ,
                text: pesan,
            });
        })

        window.livewire.on('swalAlertSuccess', (title, pesan) => {
            Swal.fire({
                //toast: true,
                //position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                onOpen: (toast) => {
                  toast.addEventListener('mouseenter', Swal.stopTimer)
                  toast.addEventListener('mouseleave', Swal.resumeTimer)
                },
                icon: 'success',
                title: title ,
                text: pesan,
            });
        })





        window.livewire.on('swalDeleted', (tujuan,idhapus) => {
            Swal.fire({
              title: 'Anda yakin?',
              text: "Anda akan menghapus data tersebut!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Ya, hapus!'
            }).then((result) => {
              if (result.value) {

                window.livewire.emit(tujuan,idhapus);

                Swal.fire(
                  'Terhapus!',
                  'data telah dihapus.',
                  'success'
                )

              }
            });
          })


      </script>
<?php $__env->stopSection(); ?>















    
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kiki/1Sites/skripsi/resources/views/page/Preference/master.blade.php ENDPATH**/ ?>