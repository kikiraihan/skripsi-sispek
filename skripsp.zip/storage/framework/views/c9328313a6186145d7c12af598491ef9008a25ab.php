<?php $__env->startSection('content'); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <span class="h4 mb-0 text-gray-800">
            <span class="d-none d-md-inline">Selamat datang, <?php echo e($user->dosen->nama); ?>!</span>
            <span class="d-md-none">Hi, Welcome!</span>
        </span>

        <div class="dropdown no-arrow dropleft float-right mr-1 mr-md-2">
            <a href="#" class="btn btn-sm btn-light d-sm-inline-block btn btn-sm btn-primary shadow-sm" data-toggle="dropdown">
                
                Pengaturan
            </a>
            <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                <a onclick="window.livewire.emit('bukaGantiPassword')" data-toggle="modal" data-target="#modalInput"  class="dropdown-item "  href="#"><i class="fas fa-redo-alt fa-sm"></i> Ganti Password</a>
                
                <a onclick="window.livewire.emit('bukaEditProfil')" data-toggle="modal" data-target="#modalInput"  class="dropdown-item "  href="#"><i class="fas fa-user-edit fa-sm"></i> Edit Profil</a>
            </div>
        </div>

        
    </div>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-xl"  id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">

            <div class="modal-content">
                <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('editkredensialuser', [])->dom;
} elseif ($_instance->childHasBeenRendered('qM2vVER')) {
    $componentId = $_instance->getRenderedChildComponentId('qM2vVER');
    $componentTag = $_instance->getRenderedChildComponentTagName('qM2vVER');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qM2vVER');
} else {
    $response = \Livewire\Livewire::mount('editkredensialuser', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('qM2vVER', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
            </div>


        </div>
    </div>





    <div class="row align-items-end">

        <div class="col-md-6 mb-4">
            <div class="row no-gutters my-3 align-items-center justify-content-center">
                <div class="col-5 px-1">
                    <div class="card shadow-sm overflow-hidden mx-auto" style="max-height:14em;max-width:14em">
                        <img src="<?php echo e($user->gravatar); ?>" alt="" class="w-100 h-100">
                    </div>
                </div>
                <div class="col-7 px-1 ">
                    <div class="card border-light shadow-sm">
                        <ul class="list-group list-group-flush small ">
                            <li class="list-group-item text-right align-items-center "><span class="float-left small">Nama : </span><?php echo e($user->dosen->nama); ?></li>
                            <li class="list-group-item text-right align-items-center "><span class="float-left small">NIP : </span> <?php echo e($user->dosen->nip); ?></li>
                            <li class="list-group-item text-right align-items-center "><span class="float-left small">Email : </span><?php echo e($user->email); ?></li>
                            <li class="list-group-item text-right align-items-center "><span class="float-left small">Username : </span><?php echo e($user->username); ?></li>
                            <li class="list-group-item text-right align-items-center "><span class="float-left small">Role : </span>
                                <?php $__currentLoopData = json_decode($user->roles->pluck('name')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="bg-light text-secondary px-2 rounded font-weight-bold border"><?php echo e($item); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </li>
                        </ul>

                    </div>
                </div>
            </div>


            <div class="row no-gutters">

                <!-- Earnings (Monthly) Card Example -->
                <div class="col-md-4 mb-4 px-md-2">
                    <div class="card border-left-primary shadow-sm  py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Mahasiswa PA </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($user->dosen->mahasiswapa->count()); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>

                <!-- Earnings (Monthly) Card Example -->
                <div class="col-md-4 mb-4 px-md-2">
                    <div class="card border-left-success shadow-sm  py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Mahasiswa PA ipk > 3</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($mahasiswa_ipkbaik->count()); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check fa-2x text-gray-300"></i>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>

                <!-- Earnings (Monthly) Card Example -->
                <div class="col-md-4 mb-4 px-md-2">
                    <div class="card border-left-warning shadow-sm  py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Mahasiswa PA ipk < 2.5</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($mahasiswa_ipkkurang->count()); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-exclamation-circle fa-2x text-gray-300"></i>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>


            </div>



        </div>










        <div class="col-md-6 mb-4">

            <div class="card mb-4 mx-md-2">
                
                <div class="card-body p-0">
                    <?php if($mahasiswa_menurun_ipk->isEmpty()): ?>
                        <div class="text-center  mt-5 mb-5">
                            <img class="w-50 d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/like (1).png')); ?>" alt="logout">
                            <span class="text-secondary">Tidak ada mahasiswa yang menurun ipk (> 0.25) pada semester ini</span>
                            <br><br>
                        </div>
                        <?php else: ?>
                        <label class="mb-0 small px-2 py-1">Mahasiswa yang menurun ipk (> 0.25) pada semester ini</label>
                            <div class="table-responsive">
                                <table class="table table-striped mb-0">
                                    <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>IPK Sekarang</th>
                                        <th>IPK Sebelumnya</th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $mahasiswa_menurun_ipk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($keg->nama); ?></td>
                                        <td><?php echo e($keg->ipksekarang); ?></td>
                                        <td><?php echo e($keg->IpkSebelumnyaBerubah); ?></td>

                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        <?php endif; ?>
                </div>
            </div>


        </div>


        <div class="col-md-12 mb-4">

            <div class="card mb-4 mx-md-2">
                <div class="card-header bg-white border-bottom-0 py-3">
                    <span class="m-0 font-weight-bold text-capitalize bg-light rounded p-2 text-dark">
                        <i class="fas fa-exclamation-circle text-gray-300"></i> Mahasiswa memiliki nilai C-, D, E
                    </span>

                    <span class="float-right">
                        <span class="small font-weight-bold">
                            <i class="fas fa-users  fa-sm"></i> <?php echo e($mahasiswa_nilai_e->count()); ?>

                        </span>
                        <span class="d-none d-md-inline">
                            mahasiswa ditemukan
                        </span>
                    </span>

                </div>
                <div class="card-body">

                    <div class="row no-gutters">
                        <?php $no=1 ?>
                        <?php $__currentLoopData = $mahasiswa_nilai_e->chunk(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 mb-3 px-3">
                            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m_nilai_e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <a href="<?php echo e(route('akademik.lihat', ['id'=>$m_nilai_e->id])); ?>" class="d-block text-secondary py-1">
                                <span class="
                                <?php if($m_nilai_e->ipksekarang>3): ?> font-weight-bold text-success
                                <?php elseif($m_nilai_e->ipksekarang<2.5): ?>  text-warning
                                <?php endif; ?>
                                ">
                                    
                                    <?php echo e($m_nilai_e->nama); ?>

                                    <sup class="badge badge-light text-secondary"> <?php echo e($m_nilai_e->mkmengulang); ?></sup>
                                </span>
                                <span class="text-primary font-weight-bold float-right">
                                    <?php echo e($m_nilai_e->semester); ?>

                                </span>
                            </a>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

                <div class="card-footer bg-white small">
                    <span class="font-weight-bold d-block">Keterangan : </span>
                    <span class="font-weight-bold text-success"> Hijau </span>, Mahasiswa IPK > 3. <br>
                    <span class="text-warning"> Kuning </span>, Mahasiswa IPK < 2,5. <br>
                    <span class="text-primary font-weight-bold">7</span>, Semester terakhir kali.<br>
                    <sup class="badge badge-light text-secondary"> 2</sup>, Jumlah matakuliah mengulang.<br>
                </div>
            </div>


        </div>









    </div>











<?php $__env->stopSection(); ?>





<?php $__env->startSection('style-halaman'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-halaman'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>


    <script>

        window.livewire.on('swalUpdated', () => {
            Swal.fire({
              toast: true,
              position: 'top-end',
              showConfirmButton: false,
              timer: 2000,
              //timerProgressBar: true,
              onOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
              },
                icon: 'success',
                title: 'Berhasil' ,
                text: 'data telah diubah!',
                confirmButtonText: 'Oke',
            });
            $('#modalInput').modal('hide');
            location.reload();
          })

        //window.livewire.on('tutupModal', () =>
        //{
        //    $('#modalInput').modal('hide');
        //})
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kiki/1Sites/skripsi/resources/views/page/Dashboard/dashboard-dosen.blade.php ENDPATH**/ ?>