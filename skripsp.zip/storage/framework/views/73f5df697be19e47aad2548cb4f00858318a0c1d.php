
<!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow-sm">


        <?php if(
            strpos($_SERVER['REQUEST_URI'], 'mahasiswa/akademik/') OR
            strpos($_SERVER['REQUEST_URI'], 'mahasiswa/profil/')
        ): ?>
        <a href="#" onclick="window.history.back()" class="btn btn-link ">
            <i class="fas fa-arrow-left fa-lg"></i>
        </a>
        <?php endif; ?>




        <!-- Sidebar Toggle (Topbar) -->
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle">
        <i class="fa fa-bars"></i>
        </button>


        <div class="text-uppercase font-weight-bold ml-2 small">
            
            SPK - Rekomendasi Mahasiswa <sup>#1</sup>
        </div>









        <!-- Topbar Search -->
        

        <!-- Topbar Navbar -->
        <ul class="navbar-nav ml-auto">

        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
        

        <!-- Nav Item - Alerts -->
        




        <div class="topbar-divider d-none d-sm-block"></div>

        <!-- Nav Item - User Information -->
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                <?php echo e(Auth::user()?Auth::user()->KredensialUserNama:"kosong belum login"); ?>

            </span>
            <img class="img-profile rounded-circle" src="
            <?php echo e(Auth::user()?auth::user()->gravatar:asset('assets_landing/img/avatar_2x.png')); ?>

            ">
            </a>
            <!-- Dropdown - User Information -->
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
            <?php if(auth()->check() && auth()->user()->hasRole('Mahasiswa')): ?>
            <a class="dropdown-item" href="<?php echo e(route('biodata.my')); ?>">
                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                Biodata
            </a>
            <div class="dropdown-divider"></div>
            <?php endif; ?>
            
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                Logout
            </a>
            </div>
        </li>

        </ul>



    </nav>
<!-- End of Topbar -->

<?php /**PATH /home/kiki/1Sites/skripsi/resources/views/layouts-auth/nav.blade.php ENDPATH**/ ?>