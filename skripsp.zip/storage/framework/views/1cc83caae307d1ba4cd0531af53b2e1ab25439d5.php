<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
         
        <img src="<?php echo e(asset('ilustrasi/sispekp.svg')); ?>" width="40pt">
        <div class="sidebar-brand-text mx-3" 
        
        >
        <?php echo e(config('app.name', 'Laravel')); ?> 
        <sup>#1</sup>
        </div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item ">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          
          <i class="fas fa-fw fa-home"></i>
          <span>Beranda</span></a>
      </li>


      <?php if(auth()->check() && auth()->user()->hasRole('Mahasiswa')): ?>
        

        <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
            <i class="fas fa-fw fa-table"></i>
            <span>Data</span>
          </a>
          <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <h6 class="collapse-header">Activity:</h6>
              <a class="collapse-item" href="<?php echo e(route('kegiatan.my')); ?>">Non Akademik</a>
              <a class="collapse-item" href="<?php echo e(route('ormawa.my')); ?>">Organisasi</a>
              <a class="collapse-item" href="<?php echo e(route('prestasi.my')); ?>">Prestasi</a>
              <div class="collapse-divider"></div>
              <h6 class="collapse-header">Keluarga :</h6>
              <a class="collapse-item" href="<?php echo e(route('orangtua.my')); ?>">Orang Tua</a>
              <a class="collapse-item" href="<?php echo e(route('saudara.my')); ?>">Saudara</a>
              <h6 class="collapse-header">Tentang saya:</h6>
              <a class="collapse-item" href="<?php echo e(route('biodata.my')); ?>">Biodata</a>
            </div>
          </div>
        </li>

        <li class="nav-item ">
          <a class="nav-link" href="<?php echo e(route('akademik.my')); ?>">
            
            <i class="fas fa-chart-pie"></i>
            <span>Akademik</span></a>
        </li>
      <?php endif; ?>



      <?php if(auth()->check() && auth()->user()->hasAnyRole('Kajur|Kaprodi|Admin|Super Admin|Dosen')): ?>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-user"></i>
          <span>Mahasiswa</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Mahasiswa:</h6>
            <?php if(auth()->check() && auth()->user()->hasRole('Dosen')): ?>
            <a class="collapse-item" href="<?php echo e(route('mahasiswa.pa')); ?>">Mahasiswa PA</a>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasAnyRole('Kajur|Kaprodi|Admin|Super Admin')): ?>
            <a class="collapse-item" href="<?php echo e(route('mahasiswa.all')); ?>">Semua Mahasiswa</a>
            <?php endif; ?>
          </div>
        </div>
      </li>
      <?php endif; ?>

      <?php if(auth()->check() && auth()->user()->hasAnyRole('Kajur|Kaprodi|Admin')): ?>
      <li class="nav-item ">
        <a class="nav-link"  href="<?php echo e(route('master.matakuliah')); ?>">
          <i class="fas fa-eye"></i>
          <span>Monitoring Matakuliah</span></a>
      </li>
      <?php endif; ?> 

      


      


      <?php if(auth()->check() && auth()->user()->hasAnyRole('Kajur|Kaprodi|Admin|Super Admin|Dosen')): ?>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Rekomendasi
      </div>

      <li class="nav-item ">
        <a class="nav-link" href="<?php echo e(route('masterkriteria')); ?>">
          
          <i class="fas fa-th-large"></i>
          
          <?php if(auth()->check() && auth()->user()->hasRole('Super Admin')): ?>
          <span>Master Kriteria</span>
          <?php else: ?>
          <span>Kriteria</span>
          <?php endif; ?>

        </a>
      </li>

      

      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('masterpreferensi')); ?>">
          <i class="fas fa-th-large"></i>
          <span>Preferensi</span>
        </a>
      </li>

      <?php endif; ?>

      <?php if(auth()->check() && auth()->user()->hasAnyRole('Kajur|Kaprodi|Admin|Super Admin')): ?>

      <?php if(Auth::user()->hasRole('Kaprodi') OR Auth::user()->hasRole('Kajur')): ?>
      <li class="nav-item ">
        <a class="nav-link" href="<?php echo e(route('rekomendasi.otomatis')); ?>">
          
          <i class="fab fa-searchengin"></i>
          <span>Rekomendasi Otomatis</span>
        </a>
      </li>
      <?php endif; ?>




      <!-- Divider -->
      <hr class="sidebar-divider">
      <div class="sidebar-heading">
        Kelola
      </div>

      <?php if(!Auth::user()->hasRole('Kaprodi')): ?>
      <li class="nav-item ">
        <a class="nav-link" href="<?php echo e(route('master.admindosen')); ?>">
          <i class="fas fa-users"></i>
          <span>User Management</span></a>
      </li>

      <li class="nav-item ">
        <a class="nav-link"  href="<?php echo e(route('import')); ?>">
          <i class="fas fa-fw fa-truck-loading"></i>
          
          <span>Import</span></a>
      </li>
      <?php endif; ?>
      
      
      <?php endif; ?>


      




      <!-- Divider -->
      







      <!-- Sidebar Toggler (Sidebar) -->
      <br>
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
<!-- End of Sidebar --><?php /**PATH /Users/mohzulkiflikatili/1SiteKiki/skripsi/resources/views/layouts-auth/sidebar.blade.php ENDPATH**/ ?>