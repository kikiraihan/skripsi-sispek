<div>




    <div class="card shadow mb-4 overflow-hidden">
        <div class="card-header border-bottom-0 font-weight-bold text-primary ">Prestasi</div>

        <div class="card-body px-0 py-0">
            <?php if($prestasi->isEmpty()): ?>
            <div class="text-center  mt-5 mb-5">
              <img class="w-50 d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/achievement_.svg')); ?>" alt="logout">
              <h5>Prestasi</h5>
              <span class="text-secondary">belum ada data prestasi</span>
              <br><br>
            </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped mb-0">
                        <thead class="text-capitalize">
                          <tr>
                              <th>judul</th>
                              <th>tanggal</th>
                              <th class="d-none d-md-table-cell">tingkat</th>
                              <th>peringkat</th>
                              <th class="d-none d-md-table-cell">lokasi</th>
                              <th class="d-none d-md-table-cell">kategori</th>
                              <th class="d-none d-md-table-cell">Sertifikat</th>
                              <th class="d-none d-md-table-cell">status</th>
                              <th>aksi</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $prestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($p->judul); ?></td>
                              <td><?php echo e($p->tanggal->formatLocalized("%d %B %Y")); ?>, <span class="small"><?php echo e($p->tanggal->diffForHumans()); ?></span></td>
                              <td class="d-none d-md-table-cell"><?php echo e($p->tingkat); ?></td>
                              <td><?php echo e($p->peringkat); ?></td>
                              <td class="d-none d-md-table-cell"><?php echo e($p->lokasi); ?></td>
                              <td class="d-none d-md-table-cell"><?php echo e($p->kategori); ?></td>
                              <td class="d-none d-md-table-cell"><?php echo e($p->sertifikat); ?></td>
                              <td class="d-none d-md-table-cell"><?php echo e($p->status); ?></td>
                              <td>
                                <div class="dropdown no-arrow position-absolute dropleft">
                                  <a href="#" class="btn btn-sm btn-light" data-toggle="dropdown">
                                      ☰
                                  </a>
                                  <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                                    <a wire:click="bukaUpdate(<?php echo e($p->id); ?>)" data-toggle="modal" data-target="#modalInput"  class="dropdown-item "  href="#"><i class="fas fa-edit text-primary"></i> Edit </a>
                                    
                                    <a wire:click="$emit('swalAndaYakin','prestasiFixHapus',<?php echo e($p->id); ?>,'Anda akan menghapus data tersebut!')"  class="dropdown-item "  href="#"><i class="fas fa-trash text-danger"></i> Hapus </a>
                                  </div>
                                </div>
                              </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>


        </div>

        <button wire:click="bukaTambah()" type="button" data-toggle="modal" data-target="#modalInput" href="#" class="btn btn-block btn-light rounded-0 ">Prestasi baru <i class="fas fa-plus "></i></button>
    </div>




</div>
<?php /**PATH /home/kiki/1Sites/skripsi/resources/views/livewire/myprestasi.blade.php ENDPATH**/ ?>