<div>

    <h5 class="text-primary">Konfigurasi Preferensi Baru</h5><br>


    <div class="card shadow-sm mb-4 ">


        <div class="card-body ">

            <div class="row no-gutters">
                <div class="col-md-6 p-2">
                    <label >
                        Judul
                    </label>
                    <input wire:model.debounce.500ms="judul" type="text" class="form-control" placeholder="rekomendasi beasiswa, rekomendasi utusan lomba programming, dll">
                </div>

                <div class="col-md-6 p-2">
                    <label >
                        Alternatif
                    </label>
                    <div class="form-group">
                        <select wire:model.lazy="model_type" class="form-control <?php $__errorArgs = ['model_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            
                            <option value="App\Models\Mahasiswa">Mahasiswa</option>

                        </select>
                        <?php $__errorArgs = ['model_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <?php if($judul AND $model_type): ?>
            <br>
            <hr>
            <h5 class="text-primary">#1 Pilih Kriteria</h5><br>
            <div class="row">
                <div class="col-md-6">
                    <div class="input-group">
                        <div class="input-group-prepend ">
                          <div class="input-group-text border-right-0 bg-white" id="btnGroupAddon">
                            <i class="fas fa-search text-primary"></i>
                          </div>
                        </div>
                        <input wire:model.debounce.500ms="searchKriteria" type="text" class="form-control" placeholder="cari kriteria">
                    </div>
                    <div class="custom-control custom-checkbox mt-3 ">
                        <input wire:model="tampilnilai" type="checkbox" class="custom-control-input" id="customCheck1">
                        <label class="custom-control-label" for="customCheck1">Tampilkan kriteria nilai matakuliah</label>
                    </div>
                    <?php if($kriteria!=null): ?>
                        <ul class="list-group my-3">
                            <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item  rounded-top-0">
                                <?php echo e($kri->title); ?> <span class="badge badge-info"><?php echo e($kri->jenis); ?></span>
                                <button wire:click="addKriteria(<?php echo e($kri->id); ?>)" class="float-right btn btn-primary btn-sm px-3">
                                    +
                                </button>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php echo e($kriteria->links()); ?>

                        <label class="small" >Ditemukan : <?php echo e($searchKriteriaCount); ?></label>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">

                    <?php if($this->KriteriaTerpilihInModel!=null): ?>

                    

                    <span class="d-block text-center mb-2 text-primary font-weight-bold">Penentuan Orientasi Kriteria (Benefit/Cost)</span>
                    
                    
                    

                    <ul class="list-group mb-3">
                        <?php $__currentLoopData = $this->KriteriaTerpilihInModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <li class="list-group-item">
                            <div class="row">

                                <div class="col-md-8">
                                    <span class="small">
                                        <?php echo e($kt->title); ?>

                                    </span>
                                    <span class="bg-gray-200 px-1 rounded border border-secondary"><?php echo e($kt->id); ?></span>
                                </div>

                                <div class="col-6 col-md-3">
                                    <div class="form-group">
                                        <select wire:model.lazy="orientasi.<?php echo e($kt->id); ?>" class="form-control <?php $__errorArgs = ['orientasi[<?php echo e($kt->id); ?>]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            
                                            <option value="benefit">Benefit</option>
                                            <option value="cost">Cost</option>
                                        </select>
                                        <?php $__errorArgs = ['orientasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-6 col-md-1">
                                    <button wire:click="deleteAddedKriteria(<?php echo e($kt->id); ?>)"  class="float-right btn btn-sm btn-danger px-3"  >
                                        X
                                    </button>
                                </div>


                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <button wire:click="prosesKriteria()" class="btn btn-primary btn-block float-right " >Proses &rarr;</button>
                    <?php endif; ?>


                </div>
            </div>
            <?php endif; ?>


            <?php if($matriksKriteria!=null): ?>
            <br><hr>

                <h5 class="text-primary">#2 Perbandingan Berpasangan</h5><br>

                <div class="row p-2 text-center">
                    <div class="col px-0 mx-0 text-center font-weight-bold text-uppercase">
                        M
                    </div>
                    <?php $__currentLoopData = $addedKriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col px-0 mx-0 ">
                        <span class="bg-gray-200 px-1 rounded border border-secondary"><?php echo e($item); ?></span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php $__currentLoopData = $matriksKriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a=>$baris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row p-2 text-center">
                    <div class="col px-0 mx-0 ">
                        <span class="bg-gray-200 px-1 rounded border border-secondary">
                            <?php echo e($addedKriteria[$a]); ?>

                        </span>
                    </div>
                    <?php $__currentLoopData = $baris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b=>$kolom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col px-0 mx-0">
                        
                        <button wire:click="openInputMatriks(<?php echo e($a); ?>,<?php echo e($b); ?>,<?php echo e($addedKriteria[$a]); ?>,<?php echo e($addedKriteria[$b]); ?>,<?php echo e($kolom); ?>)"
                            class="
                            btn btn-link font-weight-bold
                            <?php if($kolom==0): ?>
                            text-danger
                            <?php endif; ?>
                            "
                        >
                            <?php echo e($kolom); ?>

                        </button>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                

                <div class="mt-4">
                    <button wire:click="prosesNormalisasi()" class="btn btn-primary" >Uji konsistensi &rarr;</button>
                </div>
            <?php endif; ?>



            <?php if($cr<0.10 AND $matriksNormalised): ?>
            <br><hr>

            <h5 class="text-primary">#3 Hasil</h5><br>

            <div class="row align-items-center">

                <div class="col-md-6">
                    <label>Bobot Kriteria</label>
                    <ul class="list-group">
                        <?php for($i = 0; $i < count($this->KriteriaTerpilihInModel); $i++): ?>
                            <li class="list-group-item">
                                <span class="small">
                                    <?php echo e($this->KriteriaTerpilihInModel[$i]->title); ?>

                                </span>
                                <span class="bg-gray-200 px-1 rounded border border-secondary">
                                    <?php echo e($this->KriteriaTerpilihInModel[$i]->id); ?>

                                </span>
                                 <span class="float-right font-weight-bold">
                                    : <?php echo e(round($bobotKriteria[$i],2)); ?>

                                 </span>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </div>
                <div class="col-md-6">
                    <div>
                        <div class="rounded bg-light h5 d-inline p-3 text-primary font-weight-bold">
                            Rasio Konsistensi = <?php echo e(round($cr,2)); ?>

                        </div>
                    </div>
                </div>

            </div>
            <br>
            <div class="form-group">
                <label>Catatan</label>
                <textarea wire:model.lazy="catatan"  class="form-control" placeholder="Catatan tambahan.."></textarea>
                <sub class="text-secondary">*boleh kosong</sub>
            </div>

            <div class="mt-4">
                <button wire:click="prosesSimpan()" class="btn btn-primary" <?php if($cr>0.1): ?> disabled <?php endif; ?> >Simpan</button>
            </div>

            <?php endif; ?>

        </div>


    </div>

</div>
<?php /**PATH C:\Users\Asus\Documents\1SiteKiki\skripsi\resources\views/livewire/rekomendasi/masterpreferensiinput.blade.php ENDPATH**/ ?>