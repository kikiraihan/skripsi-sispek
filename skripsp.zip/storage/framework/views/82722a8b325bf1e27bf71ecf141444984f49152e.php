<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">
                <?php if($user->id==Auth::user()->id): ?>
                Beranda
                <?php else: ?>
                Profile Page
                <?php endif; ?>
            </h1>
            <div>
                <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                <?php if(!Auth::user()->hasRole('Mahasiswa')): ?>
                <a href="#" onclick="tampilKonfirmasiReset()" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm"><i class="fas fa-redo-alt fa-sm text-white-50"></i> Reset Password</a>
                <?php endif; ?>
            </div>
        </div>


        <div class="row">


            <div class="col-lg-4 order-1">

                <div class="row no-gutters my-3 align-items-center justify-content-center">
                    <div class="col-5 col-md-7 px-1 ">
                        <div class="card shadow-sm overflow-hidden mx-auto" style="max-height:21em;max-width:21em">
                            <img src="<?php echo e($user->gravatar); ?>" alt="" class="w-100 h-100">
                        </div>
                    </div>
                    <div class="col-7 col-md-12 px-1 mt-md-3">
                        <div class="card border-light shadow-sm">
                            <ul class="list-group list-group-flush small ">
                                <li class="list-group-item text-right align-items-center "><span class="float-left small">Nama : </span><?php echo e($user->mahasiswa->nama); ?></li>
                                <li class="list-group-item text-right align-items-center "><span class="float-left small">NIM : </span> <?php echo e($user->mahasiswa->nim); ?></li>
                                <li class="list-group-item text-right align-items-center "><span class="float-left small">Prodi : </span> <?php echo e($user->mahasiswa->prodi); ?>/<?php echo e($user->mahasiswa->angkatan); ?></li>
                                <li class="list-group-item text-right align-items-center "><span class="float-left small">Usia : </span> <?php echo e($user->mahasiswa->usia); ?> Tahun</li>
                            </ul>

                        </div>
                    </div>
                </div>

            </div>


            <div class="col-lg-8 order-md-2 order-4">
                <div class="card shadow mb-2 overflow-auto" style="max-height: 28em">
                    

                    <?php if($user->mahasiswa->organisasi->isEmpty()): ?>
                        <div class="text-center  mt-5 ">
                            <img class="w-50 d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/startup_.svg')); ?>" alt="logout">
                            <h5>Organisasi</h5>
                            <span class="text-secondary">belum ada data ormawa yang di ikuti</span>
                            <br><br>

                            <?php if($user->id==Auth::user()->id): ?>
                            <li class="list-group-item text-center align-items-center bg-info ">
                                <a href="#" class="btn btn-block btn-info text-center">Tambahkan data baru <i class="fas fa-plus "></i></a>
                            </li>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                    <!-- Card Body -->
                    <div class="card-body bg-info text-white px-0">
                        <h6 class="px-3 text-center font-weight-bold"> Ormawa </h6>
                        <ul class="list-group list-group-flush ">

                            <?php $__currentLoopData = $user->mahasiswa->organisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            

                            <li class="list-group-item text-right align-items-center bg-info pb-0">
                                <span class="float-left"><?php echo e($org->nama); ?> </span>
                                <div class="small">
                                    <br>
                                    Periode :
                                    <?php echo e($org->pivot->periode_dari); ?> - <?php echo e($org->pivot->periode_sampai); ?>

                                    <br>
                                    Website :
                                    <?php echo e($org->website); ?>

                                    <br>
                                    Binaan :
                                    <?php echo e($org->binaan); ?>

                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <?php if($user->id==Auth::user()->id): ?>
                            <li class="list-group-item text-center align-items-center bg-info pb-0">
                                <a href="<?php echo e(route('ormawa.my')); ?>" class="btn btn-block btn-info text-center">Tambahkan data baru <i class="fas fa-plus "></i></a>
                            </li>
                            <?php endif; ?>


                        </ul>
                    </div>
                    <?php endif; ?>

                    <?php if($user->mahasiswa->prestasi->isEmpty()): ?>
                        <div class="text-center  mt-5">
                            <img class="w-50 d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/achievement_.svg')); ?>" alt="logout">
                            <h5>Prestasi</h5>
                            <span class="text-secondary">data prestasi tidak ditemukan</span>
                            <br><br>

                            <?php if($user->id==Auth::user()->id): ?>
                            <li class="list-group-item text-center align-items-center bg-success">
                                <a href="#" class="btn btn-block btn-success btn-success text-center">Tambahkan data baru <i class="fas fa-plus "></i></a>
                            </li>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>

                    <div class="card-body bg-success text-white px-0">
                        <h6 class="px-3 text-center font-weight-bold"> Prestasi </h6>
                        <ul class="list-group list-group-flush ">

                            

                            <?php $__currentLoopData = $user->mahasiswa->prestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item text-right align-items-center bg-success">
                                <span class="float-left "><?php echo e($p->judul); ?>  </span>
                                <div class="small">
                                    <br>
                                    Peringkat/Tingkat :
                                    <?php echo e($p->peringkat); ?> / <?php echo e($p->tingkat); ?>

                                    <br>
                                    Kategori :
                                    <?php echo e($p->kategori); ?>

                                    <br>
                                    Lokasi, tanggal :
                                    <?php echo e($p->lokasi); ?>, <?php echo e($p->tanggal->formatLocalized("%d %B %Y")); ?>

                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if($user->id==Auth::user()->id): ?>
                            <li class="list-group-item text-center align-items-center bg-success">
                                <a href="<?php echo e(route('prestasi.my')); ?>" class="btn btn-block btn-success text-center">Tambahkan data baru <i class="fas fa-plus "></i></a>
                            </li>
                            <?php endif; ?>




                        </ul>
                    </div>
                    <?php endif; ?>





                </div>
            </div>

            <div class="col-lg-4 order-2 order-md-3">
                <div class="card shadow mb-3">
                    <div class="card-header py-3">
                      <h6 class="m-0 font-weight-bold text-primary">Akademik</h6>
                    </div>


                    <div class="card-body pt-2">
                        <div class="row align-items-center justify-content-center">
                            <div class="col-12">
                                <div class="chart-pie pt-2 pb-2"><div class="chartjs-size-monitor"><div class="chartjs-size-monitor-expand"><div class=""></div></div><div class="chartjs-size-monitor-shrink"><div class=""></div></div></div>
                                    <canvas id="AkademikPieChart" width="662" height="490" class="chartjs-render-monitor" style="display: block; height: 245px; width: 331px;"></canvas>
                                </div>
                                <div class="mt-2 text-center small">
                                    <span class="mr-2">
                                    <i class="fas fa-circle text-primary"></i> A
                                    </span>
                                    <span class="mr-2">
                                    <i class="fas fa-circle text-info"></i> B
                                    </span>
                                    <span class="mr-2">
                                    <i class="fas fa-circle text-warning"></i> C
                                    </span>
                                    
                                    <span class="mr-2">
                                        <i class="fas fa-circle text-danger"></i> tidak lulus
                                        
                                    </span>
                                    
                                </div>
                            </div>

                            


                        </div>
                    </div>


                    <div class="card-body">

                      <h4 class="small font-weight-bold">Perkuliahan <span class="float-right"><?php echo e(round(($user->mahasiswa->skslulus/144)*100,2)); ?>%</span></h4>
                      <div class="progress mb-4">
                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e(round(($user->mahasiswa->skslulus/144)*100,2)); ?>%" aria-valuenow="<?php echo e(round(($user->mahasiswa->skslulus/144)*100,2)); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>


                      <?php if($user->id==Auth::user()->id): ?>
                      <a href="<?php echo e(route('akademik.my')); ?>" class="btn btn-primary btn-lg btn-block"> <span class="small">Selengkapnya <i class="fas fa-arrow-right "></i> </span></a>
                      <?php else: ?>
                      <a href="<?php echo e(route('akademik.lihat',['id'=>$user->mahasiswa->id])); ?>" class="btn btn-primary btn-lg btn-block"> <span class="small">Selengkapnya <i class="fas fa-arrow-right "></i> </span></a>
                      <?php endif; ?>


                    </div>
                  </div>
            </div>



            <div class="col-lg-8 order-3 order-md-4">
                <div class="card shadow mb-4 overflow-auto" style="max-height: 33.5em">

                    <div class="card-header border-bottom-0 py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Non Akademik</h6>

                        <?php if($user->id==Auth::user()->id): ?>
                        <div class="dropdown no-arrow">
                          <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                          </a>
                          <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                            <div class="dropdown-header">Opsi :</div>
                                <a class="dropdown-item" href="<?php echo e(route('kegiatan.my')); ?>"><i class="fas fa-edit text-primary"></i> Edit Kegiatan</a>
                                
                            </div>
                        </div>
                        <?php endif; ?>

                    </div>

                    <div class="card-body px-0 py-0">
                        <?php if($user->mahasiswa->kegiatan->isEmpty()): ?>
                        <div class="text-center  mt-5 mb-5">
                            <img class="w-50 d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/adventure_.svg')); ?>" alt="logout">
                            <span class="text-secondary">data kegiatan non akademik tidak ditemukan</span>
                            <br><br>
                        </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped mb-0">
                                    <thead>
                                    <tr>
                                        <th>Judul</th>
                                        <th>Tanggal</th>
                                        <th>Lokasi</th>
                                        <th class="d-none d-md-table-cell">Penyelenggara</th>
                                        <th class="d-none d-md-table-cell">Sertifikat</th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $user->mahasiswa->kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($keg->judul); ?></td>
                                        <td><?php echo e($keg->tanggal->formatLocalized("%d %B %Y")); ?></td>
                                        <td><?php echo e($keg->lokasi); ?></td>
                                        <td class="d-none d-md-table-cell"><?php echo e($keg->penyelenggara); ?></td>
                                        <td class="d-none d-md-table-cell"><?php echo e($keg->sertifikat); ?></td>

                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        <?php endif; ?>


                    </div>


                    

                </div>
            </div>












            <div class="col-lg-4  order-5">
                <div class="card shadow mb-2 overflow-hidden">

                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Biodata</h6>
                        <?php if($user->id==Auth::user()->id): ?>
                        <div class="dropdown no-arrow">
                          <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                          </a>
                          <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                            <div class="dropdown-header">Opsi :</div>
                            <a class="dropdown-item" href="<?php echo e(route('biodata.my')); ?>"><i class="fas fa-edit text-primary"></i> Edit Bio</a>
                            
                          </div>
                        </div>
                        <?php endif; ?>
                      </div>

                        <div class=" overflow-auto">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Nama : </span> <?php echo e($user->mahasiswa->nama); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">NIM : </span> <?php echo e($user->mahasiswa->nim); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Tempat, tgl lahir : </span> <?php echo e($user->mahasiswa->tempat_lahir); ?>, <?php echo e($user->mahasiswa->tgl_lahir==null?'-':$user->mahasiswa->tgl_lahir->formatLocalized("%d %B %Y")); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Jenis Kelamin : </span> <?php echo e($user->mahasiswa->jenis_kelamin); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Golongan Darah : </span> <?php echo e($user->mahasiswa->golongan_darah); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Agama : </span> <?php echo e($user->mahasiswa->agama); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Status Kawin : </span> <?php echo e($user->mahasiswa->status); ?></li>

                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Email : </span> <?php echo e($user->email); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">No KTP : </span> <?php echo e($user->mahasiswa->no_ktp); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">No HP : </span> <?php echo e($user->mahasiswa->no_hp); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Alamat Sekarang : </span>
                                    <?php
                                    $alamat_sekarang=$user->mahasiswa->lokasi->where('jenis','alamat_sekarang')->first();
                                    ?>
                                    <?php if($alamat_sekarang==NULL): ?>
                                    -
                                    <?php else: ?>
                                    <?php echo e($alamat_sekarang->deskripsi); ?>

                                    <?php endif; ?>
                                </li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Alamat Asal : </span>
                                    <?php
                                    $alamat_asal=$user->mahasiswa->lokasi->where('jenis','alamat_asal')->first();
                                    ?>
                                    <?php if($alamat_asal==NULL): ?>
                                    -
                                    <?php else: ?>
                                    <?php echo e($alamat_asal->deskripsi); ?>

                                    <?php endif; ?>
                                </li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Asuransi : </span> <?php echo e($user->mahasiswa->asuransi); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Minat/Bakat : </span>
                                    <?php if($user->mahasiswa->minatbakat->isEmpty()): ?>
                                    -
                                    <?php else: ?>
                                    <?php $__currentLoopData = $user->mahasiswa->minatbakat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($item); ?>,<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </li>
                            </ul>
                        </div>

                </div>
            </div>




            <div class="col-lg-4  order-6">
                <div class="card shadow mb-2 overflow-hidden">

                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Orangtua</h6>
                        <?php if($user->id==Auth::user()->id): ?>
                        <div class="dropdown no-arrow">
                          <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                          </a>
                          <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                            <div class="dropdown-header">Opsi :</div>
                            <a class="dropdown-item" href="<?php echo e(route('orangtua.my')); ?>"><i class="fas fa-edit text-primary"></i> Edit Orangtua</a>
                            
                          </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class=" overflow-auto" >
                        <?php if($user->mahasiswa->orangtua->isEmpty() ): ?>
                        <div class="text-center  my-5">
                            <img class="w-50 d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/family_.svg')); ?>" alt="logout">
                            <span class="text-secondary">data orangtua tidak ditemukan</span>
                        </div>
                        <?php else: ?>
                        <ul class="list-group list-group-flush">
                            <?php $__currentLoopData = $user->mahasiswa->orangtua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ortu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-block p-3 text-center text-primary small text-capitalize font-weight-bold"><?php echo e($ortu->hubungan); ?> </div>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Nama : </span> <?php echo e($ortu->nama); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">No HP : </span> <?php echo e($ortu->no_hp); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Pendidikan terakhir : </span> <?php echo e($ortu->pendidikan_terakhir); ?></li>
                                <li class="list-group-item text-right align-items-center"><span class="float-left small">Pekerjaan/kategori : </span> <?php echo e($ortu->pekerjaan); ?> / <?php echo e($ortu->kategori_pekerjaan); ?></li>
                                <li class="list-group-item text-right align-items-center">
                                    <span class="float-left small">Penghasilan : </span> Rp. <?php echo e(number_format($ortu->nominal_penghasilan)); ?>

                                    
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </ul>
                        <?php endif; ?>
                    </div>

                </div>
            </div>

            <div class="col-lg-4  order-7">
                <div class="card shadow mb-2 overflow-hidden">

                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Saudara</h6>
                        <?php if($user->id==Auth::user()->id): ?>
                        <div class="dropdown no-arrow">
                          <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                          </a>
                          <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                            <div class="dropdown-header">Opsi :</div>
                            <a class="dropdown-item" href="<?php echo e(route('saudara.my')); ?>"><i class="fas fa-edit text-primary"></i> Edit Saudara</a>
                            
                          </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class=" overflow-auto" >
                        <?php if($user->mahasiswa->saudara->isEmpty() ): ?>
                        <div class="text-center  my-5">
                            <img class="w-50 d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/gaming_.svg')); ?>" alt="logout">
                            <span class="text-secondary">data saudara tidak ditemukan</span>
                        </div>
                        <?php else: ?>
                        <ul class="list-group list-group-flush">
                            <?php $__currentLoopData = $user->mahasiswa->saudara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saudara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-block p-3 text-center text-primary small font-weight-bold text-capitalize"><?php echo e($saudara->hubungan); ?> </div>
                            <li class="list-group-item text-right align-items-center"><span class="float-left small">Nama : </span> <?php echo e($saudara->nama); ?></li>
                            <li class="list-group-item text-right align-items-center"><span class="float-left small">Pendidikan terakhir : </span> <?php echo e($saudara->pendidikan_terakhir); ?></li>
                            <li class="list-group-item text-right align-items-center"><span class="float-left small">Bekerja/Tidak : </span> <?php echo e($saudara->bekerjakah); ?></li>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </ul>
                        <?php endif; ?>
                    </div>

                </div>
            </div>














        </div>



















<?php $__env->stopSection(); ?>



<?php $__env->startSection('script-halaman'); ?>

<!-- Page level plugins -->
<script src="<?php echo e(asset('assets_template/vendor/chart.js/Chart.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('assets_template/js/demo/chart-area-demo.js')); ?>"></script>
<script src="<?php echo e(asset('assets_template/js/demo/chart-pie-demo.js')); ?>"></script>



<script>
    // Set new default font family and font color to mimic Bootstrap's default styling
    Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#858796';

    // Pie Chart Example
    var ctx = document.getElementById("AkademikPieChart");
    var AkademikPieChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: ["A", "B", "C", "Tidak lulus", "kosong"],
        datasets: [{
        data: [<?php echo e($user->mahasiswa->nilaiA); ?>, <?php echo e($user->mahasiswa->nilaiB); ?>, <?php echo e($user->mahasiswa->nilaiC); ?>, <?php echo e($user->mahasiswa->mkmengulang); ?>, <?php echo e($user->mahasiswa->mkkosong); ?>],
        backgroundColor: ['#4e73df', '#36b9cc', '#f6c23e', '#e74a3b', '#858796'],
        hoverBackgroundColor: ['#2e59d9', '#2c9faf', '#e1b64a', '#be3326', '#575969' ],
        /*danger '#e74a3b' '#be3326'*/
        /*primary '#4e73df' '#2e59d9'*/
        /*Hijau '#1cc88a' '#17a673'*/
        hoverBorderColor: "rgba(234, 236, 244, 1)",
        }],
    },
    options: {
        maintainAspectRatio: false,
        tooltips: {
        backgroundColor: "rgb(255,255,255)",
        bodyFontColor: "#858796",
        borderColor: '#dddfeb',
        borderWidth: 1,
        xPadding: 15,
        yPadding: 15,
        displayColors: false,
        caretPadding: 10,
        },
        legend: {
        display: false
        },
        cutoutPercentage: 80,
    },
    });

</script>


<?php if(session('passwordReseted')): ?>
<script>
    Swal.fire({
        //toast: true,
        //position: 'top-end',
        showConfirmButton: false,
        timer: 1000,
        timerProgressBar: false,
        //onOpen: (toast) => {
          //toast.addEventListener('mouseenter', Swal.stopTimer)
          //toast.addEventListener('mouseleave', Swal.resumeTimer)
        //},
        icon: 'success',
        title: "Berhasil" ,
        text: 'password direset menjadi "password"!',
    });
</script>
<?php endif; ?>

<script>
    

    function tampilKonfirmasiReset(){
        Swal.fire({
            title: 'Anda yakin?',
            text: "Anda akan mereset password mahasiswa ini menjadi 'password'!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Reset!'
          }).then((result) => {
            if (result.value) {
              //Swal.fire(
                //'Berhasil!',
                //'Password mahasiswa ini telah direset.',
                //'success'
              //);
              window.location.href = "<?php echo e(route('mahasiswa.profil.resetpassword', ['id'=>$user->id])); ?>";

            }
          })

    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Documents\1SiteKiki\skripsi\resources\views/page/profile.blade.php ENDPATH**/ ?>