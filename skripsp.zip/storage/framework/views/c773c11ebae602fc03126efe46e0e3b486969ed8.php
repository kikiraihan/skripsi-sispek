<?php $__env->startSection('content'); ?>


    <?php if($komponen=="mykegiatan"): ?>
        <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mykegiatan', [])->dom;
} elseif ($_instance->childHasBeenRendered('hQMwnza')) {
    $componentId = $_instance->getRenderedChildComponentId('hQMwnza');
    $componentTag = $_instance->getRenderedChildComponentTagName('hQMwnza');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hQMwnza');
} else {
    $response = \Livewire\Livewire::mount('mykegiatan', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('hQMwnza', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

        <!-- Modal -->
        <div class="modal fade bd-example-modal-md" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-scrollable modal-md modal-dialog-centered" role="document">
            <div class="modal-content">
              <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mykegiataninput', [])->dom;
} elseif ($_instance->childHasBeenRendered('xR0SBZy')) {
    $componentId = $_instance->getRenderedChildComponentId('xR0SBZy');
    $componentTag = $_instance->getRenderedChildComponentTagName('xR0SBZy');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xR0SBZy');
} else {
    $response = \Livewire\Livewire::mount('mykegiataninput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('xR0SBZy', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
            </div>
          </div>
        </div>


    <?php elseif($komponen=="myormawa"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myormawa', [])->dom;
} elseif ($_instance->childHasBeenRendered('O6nCyVf')) {
    $componentId = $_instance->getRenderedChildComponentId('O6nCyVf');
    $componentTag = $_instance->getRenderedChildComponentTagName('O6nCyVf');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('O6nCyVf');
} else {
    $response = \Livewire\Livewire::mount('myormawa', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('O6nCyVf', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-md" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myormawainput', [])->dom;
} elseif ($_instance->childHasBeenRendered('edX3ppe')) {
    $componentId = $_instance->getRenderedChildComponentId('edX3ppe');
    $componentTag = $_instance->getRenderedChildComponentTagName('edX3ppe');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('edX3ppe');
} else {
    $response = \Livewire\Livewire::mount('myormawainput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('edX3ppe', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>


    <?php elseif($komponen=="myprestasi"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myprestasi', [])->dom;
} elseif ($_instance->childHasBeenRendered('9AEyetr')) {
    $componentId = $_instance->getRenderedChildComponentId('9AEyetr');
    $componentTag = $_instance->getRenderedChildComponentTagName('9AEyetr');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9AEyetr');
} else {
    $response = \Livewire\Livewire::mount('myprestasi', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('9AEyetr', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-md" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myprestasiinput', [])->dom;
} elseif ($_instance->childHasBeenRendered('KBiprzX')) {
    $componentId = $_instance->getRenderedChildComponentId('KBiprzX');
    $componentTag = $_instance->getRenderedChildComponentTagName('KBiprzX');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KBiprzX');
} else {
    $response = \Livewire\Livewire::mount('myprestasiinput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('KBiprzX', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>

    <?php elseif($komponen=="myorangtua"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myorangtua', [])->dom;
} elseif ($_instance->childHasBeenRendered('IKz9T4B')) {
    $componentId = $_instance->getRenderedChildComponentId('IKz9T4B');
    $componentTag = $_instance->getRenderedChildComponentTagName('IKz9T4B');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IKz9T4B');
} else {
    $response = \Livewire\Livewire::mount('myorangtua', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('IKz9T4B', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-xl" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myorangtuainput', [])->dom;
} elseif ($_instance->childHasBeenRendered('OHd2XOn')) {
    $componentId = $_instance->getRenderedChildComponentId('OHd2XOn');
    $componentTag = $_instance->getRenderedChildComponentTagName('OHd2XOn');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OHd2XOn');
} else {
    $response = \Livewire\Livewire::mount('myorangtuainput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('OHd2XOn', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>

    <?php elseif($komponen=="mysaudara"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mysaudara', [])->dom;
} elseif ($_instance->childHasBeenRendered('jqNhzdt')) {
    $componentId = $_instance->getRenderedChildComponentId('jqNhzdt');
    $componentTag = $_instance->getRenderedChildComponentTagName('jqNhzdt');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jqNhzdt');
} else {
    $response = \Livewire\Livewire::mount('mysaudara', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('jqNhzdt', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-md" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mysaudarainput', [])->dom;
} elseif ($_instance->childHasBeenRendered('VA5uebV')) {
    $componentId = $_instance->getRenderedChildComponentId('VA5uebV');
    $componentTag = $_instance->getRenderedChildComponentTagName('VA5uebV');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VA5uebV');
} else {
    $response = \Livewire\Livewire::mount('mysaudarainput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('VA5uebV', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>

    <?php elseif($komponen=="masterkriteria"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('rekomendasi.masterkriteria', [])->dom;
} elseif ($_instance->childHasBeenRendered('dKfnNNG')) {
    $componentId = $_instance->getRenderedChildComponentId('dKfnNNG');
    $componentTag = $_instance->getRenderedChildComponentTagName('dKfnNNG');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dKfnNNG');
} else {
    $response = \Livewire\Livewire::mount('rekomendasi.masterkriteria', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('dKfnNNG', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-xl" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('rekomendasi.masterkriteriainput', [])->dom;
} elseif ($_instance->childHasBeenRendered('ftAe96L')) {
    $componentId = $_instance->getRenderedChildComponentId('ftAe96L');
    $componentTag = $_instance->getRenderedChildComponentTagName('ftAe96L');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ftAe96L');
} else {
    $response = \Livewire\Livewire::mount('rekomendasi.masterkriteriainput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('ftAe96L', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>






    <?php elseif($komponen=="masterAdminDosen"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('master.admindosen', [])->dom;
} elseif ($_instance->childHasBeenRendered('xLzaQ1E')) {
    $componentId = $_instance->getRenderedChildComponentId('xLzaQ1E');
    $componentTag = $_instance->getRenderedChildComponentTagName('xLzaQ1E');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xLzaQ1E');
} else {
    $response = \Livewire\Livewire::mount('master.admindosen', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('xLzaQ1E', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('master.admindoseninput', [])->dom;
} elseif ($_instance->childHasBeenRendered('ijIT8cY')) {
    $componentId = $_instance->getRenderedChildComponentId('ijIT8cY');
    $componentTag = $_instance->getRenderedChildComponentTagName('ijIT8cY');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ijIT8cY');
} else {
    $response = \Livewire\Livewire::mount('master.admindoseninput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('ijIT8cY', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    
    
    <?php elseif($komponen=="masterMatakuliah"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('master.mastermatakuliah', [])->dom;
} elseif ($_instance->childHasBeenRendered('l50rpff')) {
    $componentId = $_instance->getRenderedChildComponentId('l50rpff');
    $componentTag = $_instance->getRenderedChildComponentTagName('l50rpff');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l50rpff');
} else {
    $response = \Livewire\Livewire::mount('master.mastermatakuliah', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('l50rpff', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
    






    <?php elseif($komponen=="mahasiswaPA"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mahasiswa.mahasiswapa', [])->dom;
} elseif ($_instance->childHasBeenRendered('QSzZrPV')) {
    $componentId = $_instance->getRenderedChildComponentId('QSzZrPV');
    $componentTag = $_instance->getRenderedChildComponentTagName('QSzZrPV');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QSzZrPV');
} else {
    $response = \Livewire\Livewire::mount('mahasiswa.mahasiswapa', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('QSzZrPV', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>


    <?php elseif($komponen=="mahasiswaall"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mahasiswa.all', [])->dom;
} elseif ($_instance->childHasBeenRendered('wfzxNdh')) {
    $componentId = $_instance->getRenderedChildComponentId('wfzxNdh');
    $componentTag = $_instance->getRenderedChildComponentTagName('wfzxNdh');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wfzxNdh');
} else {
    $response = \Livewire\Livewire::mount('mahasiswa.all', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('wfzxNdh', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>









    <?php endif; ?>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('style-halaman'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-halaman'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>




    
    
    <script>
      window.livewire.on('swalAdded', counter => {
        Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            onOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            },
            icon: 'success',
            title: 'Berhasil' ,
            text: 'berhasil menambahkan '+counter+' data!',
        });
        $('#modalInput').modal('hide');
      })

      window.livewire.on('swalUpdated', () => {
        Swal.fire({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 2000,
          //timerProgressBar: true,
          onOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          },
            icon: 'success',
            title: 'Berhasil' ,
            text: 'data telah diubah!',
            confirmButtonText: 'Oke',
        });
        $('#modalInput').modal('hide');
      })

      window.livewire.on('swalDeleted', (tujuan,idhapus) => {
        Swal.fire({
          title: 'Anda yakin?',
          text: "Anda akan menghapus data tersebut!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya, hapus!'
        }).then((result) => {
          if (result.value) {

            window.livewire.emit(tujuan,idhapus);

            Swal.fire(
              'Terhapus!',
              'data telah dihapus.',
              'success'
            )

          }
        });
      })



      window.livewire.on('tutupModal', () =>
      {
        $('#modalInput').modal('hide');
      })


      window.livewire.on('swalAndaYakin', (tujuan,idModel,pesan) => {
        Swal.fire({
          title: 'Anda yakin?',
          text: pesan,
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya!'
        }).then((result) => {
          if (result.value) {

            window.livewire.emit(tujuan,idModel);

            Swal.fire(
              'Berhasil!',
              'data telah diupdate.',
              'success'
            )

          }
        });
      })


    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mohzulkiflikatili/1SiteKiki/skripsi/resources/views/page/Datamahasiswa/main.blade.php ENDPATH**/ ?>