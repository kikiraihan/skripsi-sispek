<div>

    <h5 class="text-primary">Rekomendasi Otomatis</h5>



    <div class="card">
        <div class="card-body">
            <label class="font-weight-bold text-primary">
                #1 Pilih Preferensi
            </label>

            <div>
                <div class="input-group">
                    <div class="input-group-prepend ">
                      <div class="input-group-text border-right-0 bg-white" id="btnGroupAddon">
                        <i class="fas fa-search text-primary"></i>
                      </div>
                    </div>
                    <input wire:model.debounce.500ms="searchPreferensi" type="text" class="form-control" placeholder="Judul">
                </div>

                

                <?php if($preferensi->isEmpty()): ?>
                    <div class="text-center  mt-5 mb-5">
                        <img class="d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/fishing.svg')); ?>" alt="logout" width="35%">
                        <h5>Preferensi</h5>
                        <span class="text-secondary">tidak ditemukan</span>
                        <br><br>
                    </div>
                <?php else: ?>

                <div class="row no-gutters">

                    <?php $__currentLoopData = $preferensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-3 col-sm-6 p-2 py-3">

                        <div class="p-2 rounded bg-white border border-ligh">
                            <div class="p-1 text-center mb-3">
                                
                                <i class="fas fa-th-large fa-3x"></i>
                                <br><br>
                                <span class="card-title h5 text-capitalize"><?php echo e($m->judul); ?></span>
                            </div>

                            
                                    <button wire:click="setPreferensiToGenerate(<?php echo e($m->id); ?>)" class="font-weight-bold p-2 btn btn-primary btn-sm btn-block">
                                        Pilih
                                    </button>
                                

                        </div>


                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <?php echo e($preferensi->links()); ?>

                <label class="small" >Ditemukan : <?php echo e($searchPreferensiCount); ?></label>

                <?php endif; ?>

            </div>









        </div>
    </div>



    <?php if($preferensiToGenerate): ?>
    

    <div class="card mt-4">

        <div class="card-body">
            <label class="text-capitalize  font-weight-bold">
                Preferensi
            </label>

            <span class="float-right text-capitalize font-weight-bold">
                id : <?php echo e($preferensiToGenerate['id']); ?>

            </span>
            <br><br>


            <div class="row">
                <div class="col-md-6">

                    <ul class="list-group">
                        <li class="list-group-item">
                            <div class="justify-content-md-between d-md-flex">
                                <span class="font-weight-bold">Judul :</span>
                                <br class="d-md-none">
                                <span class="text-capitalize"><?php echo e($preferensiToGenerate['judul']); ?></span>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="justify-content-md-between d-md-flex">
                                <span class="font-weight-bold">Kriteria :</span>
                                <br class="d-md-none">
                                <span class="text-right text-capitalize">
                                    <?php $__currentLoopData = json_decode($preferensiToGenerate['kriteria']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($this->getTitleOfKriteria($id)); ?> <span class="badge badge-info"><?php echo e($kriteria->jenis); ?> : <?php echo e(round($kriteria->bobot,3)); ?></span>  <br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </span>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="justify-content-md-between d-md-flex">
                                <span class="font-weight-bold">Alternatif :</span>
                                <br class="d-md-none">
                                <span><?php echo e(str_replace("App\Models","",$preferensiToGenerate['model_type'])); ?></span>
                            </div>
                        </li>
                    </ul>
                </div>


                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <br class="d-md-none">
                            <span class="font-weight-bold">Matriks :</span><br><br>
                            <?php $matriks=json_decode($preferensiToGenerate['matriks']) ?>
                            <?php for($i = 0; $i < count($matriks); $i++): ?>
                                <?php for($z = 0; $z < count($matriks[$i]); $z++): ?>
                                    <h6 class="badge badge-secondary badge-pill p-2" style="width: 30px"><?php echo e($matriks[$i][$z]); ?></h6>
                                <?php endfor; ?>
                                <br>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
            </div>




        </div>


        <div class="card-body">
            <span class="font-weight-bold text-primary">
                #2 Filter
            </span>
            <br><br>

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <select wire:model.lazy="filter_angkatan" class="form-control <?php $__errorArgs = ['filter_angkatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">-Semua Angkatan-</option>
                            <?php
                                $carbon=\Carbon\Carbon::now()->year;
                            ?>
                            <?php for($i = 0; $i < 8; $i++): ?>
                            <option value="<?php echo e($carbon-$i); ?>"><?php echo e($carbon-$i); ?></option>
                            <?php endfor; ?>

                        </select>
                        <?php $__errorArgs = ['filter_angkatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>



                <div class="col-md-4">
                    <div class="form-group">
                        <select wire:model.lazy="filter_prodi" class="form-control <?php $__errorArgs = ['filter_prodi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">-Filter Prodi-</option>
                            <option value='S1 - Sistem Informasi'>Sistem Informasi</option>
                            <option value='S1 - Pendidikan Teknologi Informasi'>Pendidikan Teknologi Informasi</option>
                        </select>
                        <?php $__errorArgs = ['filter_prodi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <select wire:model.lazy="filter_dosenpa" class="form-control <?php $__errorArgs = ['filter_dosenpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">-Filter Dosen PA-</option>
                            <?php $__currentLoopData = App\Models\Dosen::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['filter_dosenpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>



            </div>

            




            <button wire:loading.attr="disabled" class="btn btn-primary " wire:click="generate">
                <div wire:loading.remove wire:target="generate">
                    Generate
                </div>
                <div wire:loading wire:target="generate">
                    <span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>
                    Tunggu sebentar..
                </div>
            </button>

        </div>



        <?php if($modelRanked): ?>
        <hr>
        <div class="card-body">

            <label class="text-primary font-weight-bold">Ranked </label>
            <label class="float-right small"> Diperoleh : <?php echo e(is_array($modelRanked)?count($modelRanked):0); ?> Mahasiswa</label>
            <?php
                $no=1;
            ?>
            <?php if($modelRanked!="setara"): ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $modelRanked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id_model => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">

                        <a class="<?php if($no<4): ?> text-success <?php else: ?> text-secondary <?php endif; ?> font-weight-bold" href="<?php echo e(route('mahasiswa.profil', ['id'=>$id_model])); ?>">
                            <?php echo e($no++); ?>. <?php echo e($value['model']->nama); ?> - <small><?php echo e($value['model']->angkatan); ?></small>
                        </a>

                        <span class="badge badge-primary float-right p-2 ">Nilai : <?php echo e(round($value['rank'],5)); ?></span>
                        
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php elseif($modelRanked=="setara"): ?>
                <h5 class="text-center">Setara</h5>
            <?php endif; ?>



        </div>
        <?php endif; ?>

    </div>
    <?php endif; ?>


    <?php if($modelRanked AND $rank!="setara"): ?>
    <div x-data="{ open: false }" class="card mt-3">

        <button @click="open=!open" class="btn btn-link font-weight-bold">Lihat matriks</button>


        <div class="card-body" x-show="open">
            <div class="table-responsive">
                <table class="table table-striped mb-0 table-bordered text-center">
                    
                    <tbody>
                        <?php $__currentLoopData = $this->getMatriksTitleRender(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id_model=>$perModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($id_model); ?></td>
                                <?php $__currentLoopData = $perModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id_kriteria=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="text-primary">
                                    <?php echo e($value); ?> - <?php echo e($id_kriteria); ?>

                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>


    </div>
    <?php endif; ?>



    <br><br>

</div>
<?php /**PATH C:\Users\Asus\Documents\1SiteKiki\skripsi\resources\views/livewire/rekomendasi/rekomendasiotomatis.blade.php ENDPATH**/ ?>