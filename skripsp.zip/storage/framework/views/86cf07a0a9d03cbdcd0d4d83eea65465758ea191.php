<?php $__env->startSection('content'); ?>


    <?php if($komponen=="mykegiatan"): ?>
        <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mykegiatan', [])->dom;
} elseif ($_instance->childHasBeenRendered('itCwMae')) {
    $componentId = $_instance->getRenderedChildComponentId('itCwMae');
    $componentTag = $_instance->getRenderedChildComponentTagName('itCwMae');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('itCwMae');
} else {
    $response = \Livewire\Livewire::mount('mykegiatan', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('itCwMae', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

        <!-- Modal -->
        <div class="modal fade bd-example-modal-md" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-scrollable modal-md modal-dialog-centered" role="document">
            <div class="modal-content">
              <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mykegiataninput', [])->dom;
} elseif ($_instance->childHasBeenRendered('ICUMQpy')) {
    $componentId = $_instance->getRenderedChildComponentId('ICUMQpy');
    $componentTag = $_instance->getRenderedChildComponentTagName('ICUMQpy');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ICUMQpy');
} else {
    $response = \Livewire\Livewire::mount('mykegiataninput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('ICUMQpy', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
            </div>
          </div>
        </div>


    <?php elseif($komponen=="myormawa"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myormawa', [])->dom;
} elseif ($_instance->childHasBeenRendered('sfeBR9L')) {
    $componentId = $_instance->getRenderedChildComponentId('sfeBR9L');
    $componentTag = $_instance->getRenderedChildComponentTagName('sfeBR9L');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sfeBR9L');
} else {
    $response = \Livewire\Livewire::mount('myormawa', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('sfeBR9L', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-md" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myormawainput', [])->dom;
} elseif ($_instance->childHasBeenRendered('YL99Fqi')) {
    $componentId = $_instance->getRenderedChildComponentId('YL99Fqi');
    $componentTag = $_instance->getRenderedChildComponentTagName('YL99Fqi');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YL99Fqi');
} else {
    $response = \Livewire\Livewire::mount('myormawainput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('YL99Fqi', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>


    <?php elseif($komponen=="myprestasi"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myprestasi', [])->dom;
} elseif ($_instance->childHasBeenRendered('0AqNKgD')) {
    $componentId = $_instance->getRenderedChildComponentId('0AqNKgD');
    $componentTag = $_instance->getRenderedChildComponentTagName('0AqNKgD');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0AqNKgD');
} else {
    $response = \Livewire\Livewire::mount('myprestasi', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('0AqNKgD', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-md" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myprestasiinput', [])->dom;
} elseif ($_instance->childHasBeenRendered('3gkg7s5')) {
    $componentId = $_instance->getRenderedChildComponentId('3gkg7s5');
    $componentTag = $_instance->getRenderedChildComponentTagName('3gkg7s5');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3gkg7s5');
} else {
    $response = \Livewire\Livewire::mount('myprestasiinput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('3gkg7s5', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>

    <?php elseif($komponen=="myorangtua"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myorangtua', [])->dom;
} elseif ($_instance->childHasBeenRendered('3kzzzyX')) {
    $componentId = $_instance->getRenderedChildComponentId('3kzzzyX');
    $componentTag = $_instance->getRenderedChildComponentTagName('3kzzzyX');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3kzzzyX');
} else {
    $response = \Livewire\Livewire::mount('myorangtua', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('3kzzzyX', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-xl" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myorangtuainput', [])->dom;
} elseif ($_instance->childHasBeenRendered('qQRH6wS')) {
    $componentId = $_instance->getRenderedChildComponentId('qQRH6wS');
    $componentTag = $_instance->getRenderedChildComponentTagName('qQRH6wS');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qQRH6wS');
} else {
    $response = \Livewire\Livewire::mount('myorangtuainput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('qQRH6wS', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>

    <?php elseif($komponen=="mysaudara"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mysaudara', [])->dom;
} elseif ($_instance->childHasBeenRendered('XZw8Ud5')) {
    $componentId = $_instance->getRenderedChildComponentId('XZw8Ud5');
    $componentTag = $_instance->getRenderedChildComponentTagName('XZw8Ud5');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XZw8Ud5');
} else {
    $response = \Livewire\Livewire::mount('mysaudara', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('XZw8Ud5', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-md" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mysaudarainput', [])->dom;
} elseif ($_instance->childHasBeenRendered('7f4ialf')) {
    $componentId = $_instance->getRenderedChildComponentId('7f4ialf');
    $componentTag = $_instance->getRenderedChildComponentTagName('7f4ialf');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7f4ialf');
} else {
    $response = \Livewire\Livewire::mount('mysaudarainput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('7f4ialf', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>

    <?php elseif($komponen=="masterkriteria"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('rekomendasi.masterkriteria', [])->dom;
} elseif ($_instance->childHasBeenRendered('LDZaD50')) {
    $componentId = $_instance->getRenderedChildComponentId('LDZaD50');
    $componentTag = $_instance->getRenderedChildComponentTagName('LDZaD50');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LDZaD50');
} else {
    $response = \Livewire\Livewire::mount('rekomendasi.masterkriteria', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('LDZaD50', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-xl" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('rekomendasi.masterkriteriainput', [])->dom;
} elseif ($_instance->childHasBeenRendered('72k4L3c')) {
    $componentId = $_instance->getRenderedChildComponentId('72k4L3c');
    $componentTag = $_instance->getRenderedChildComponentTagName('72k4L3c');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('72k4L3c');
} else {
    $response = \Livewire\Livewire::mount('rekomendasi.masterkriteriainput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('72k4L3c', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>






    <?php elseif($komponen=="masterAdminDosen"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('master.admindosen', [])->dom;
} elseif ($_instance->childHasBeenRendered('PhNdeem')) {
    $componentId = $_instance->getRenderedChildComponentId('PhNdeem');
    $componentTag = $_instance->getRenderedChildComponentTagName('PhNdeem');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PhNdeem');
} else {
    $response = \Livewire\Livewire::mount('master.admindosen', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('PhNdeem', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('master.admindoseninput', [])->dom;
} elseif ($_instance->childHasBeenRendered('K5CbKRH')) {
    $componentId = $_instance->getRenderedChildComponentId('K5CbKRH');
    $componentTag = $_instance->getRenderedChildComponentTagName('K5CbKRH');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('K5CbKRH');
} else {
    $response = \Livewire\Livewire::mount('master.admindoseninput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('K5CbKRH', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>






    <?php elseif($komponen=="mahasiswaPA"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mahasiswa.mahasiswapa', [])->dom;
} elseif ($_instance->childHasBeenRendered('9E6bAZq')) {
    $componentId = $_instance->getRenderedChildComponentId('9E6bAZq');
    $componentTag = $_instance->getRenderedChildComponentTagName('9E6bAZq');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9E6bAZq');
} else {
    $response = \Livewire\Livewire::mount('mahasiswa.mahasiswapa', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('9E6bAZq', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>


    <?php elseif($komponen=="mahasiswaall"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mahasiswa.all', [])->dom;
} elseif ($_instance->childHasBeenRendered('ArXRikd')) {
    $componentId = $_instance->getRenderedChildComponentId('ArXRikd');
    $componentTag = $_instance->getRenderedChildComponentTagName('ArXRikd');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ArXRikd');
} else {
    $response = \Livewire\Livewire::mount('mahasiswa.all', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('ArXRikd', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>









    <?php endif; ?>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('style-halaman'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-halaman'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>




    
    
    <script>
      window.livewire.on('swalAdded', counter => {
        Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            onOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            },
            icon: 'success',
            title: 'Berhasil' ,
            text: 'berhasil menambahkan '+counter+' data!',
        });
        $('#modalInput').modal('hide');
      })

      window.livewire.on('swalUpdated', () => {
        Swal.fire({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 2000,
          //timerProgressBar: true,
          onOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          },
            icon: 'success',
            title: 'Berhasil' ,
            text: 'data telah diubah!',
            confirmButtonText: 'Oke',
        });
        $('#modalInput').modal('hide');
      })

      window.livewire.on('swalDeleted', (tujuan,idhapus) => {
        Swal.fire({
          title: 'Anda yakin?',
          text: "Anda akan menghapus data tersebut!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya, hapus!'
        }).then((result) => {
          if (result.value) {

            window.livewire.emit(tujuan,idhapus);

            Swal.fire(
              'Terhapus!',
              'data telah dihapus.',
              'success'
            )

          }
        });
      })



      window.livewire.on('tutupModal', () =>
      {
        $('#modalInput').modal('hide');
      })


      window.livewire.on('swalAndaYakin', (tujuan,idModel,pesan) => {
        Swal.fire({
          title: 'Anda yakin?',
          text: pesan,
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya!'
        }).then((result) => {
          if (result.value) {

            window.livewire.emit(tujuan,idModel);

            Swal.fire(
              'Berhasil!',
              'data telah diupdate.',
              'success'
            )

          }
        });
      })


    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kiki/1Sites/skripsi/resources/views/page/Datamahasiswa/main.blade.php ENDPATH**/ ?>