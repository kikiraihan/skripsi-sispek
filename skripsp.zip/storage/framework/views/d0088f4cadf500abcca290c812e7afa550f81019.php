<?php $__env->startSection('content'); ?>


    <?php if($komponen=="mykegiatan"): ?>
        <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mykegiatan', [])->dom;
} elseif ($_instance->childHasBeenRendered('6LhJ2xp')) {
    $componentId = $_instance->getRenderedChildComponentId('6LhJ2xp');
    $componentTag = $_instance->getRenderedChildComponentTagName('6LhJ2xp');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6LhJ2xp');
} else {
    $response = \Livewire\Livewire::mount('mykegiatan', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('6LhJ2xp', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

        <!-- Modal -->
        <div class="modal fade bd-example-modal-md" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-scrollable modal-md modal-dialog-centered" role="document">
            <div class="modal-content">
              <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mykegiataninput', [])->dom;
} elseif ($_instance->childHasBeenRendered('I1mgP88')) {
    $componentId = $_instance->getRenderedChildComponentId('I1mgP88');
    $componentTag = $_instance->getRenderedChildComponentTagName('I1mgP88');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('I1mgP88');
} else {
    $response = \Livewire\Livewire::mount('mykegiataninput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('I1mgP88', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
            </div>
          </div>
        </div>


    <?php elseif($komponen=="myormawa"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myormawa', [])->dom;
} elseif ($_instance->childHasBeenRendered('Y0h12EN')) {
    $componentId = $_instance->getRenderedChildComponentId('Y0h12EN');
    $componentTag = $_instance->getRenderedChildComponentTagName('Y0h12EN');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Y0h12EN');
} else {
    $response = \Livewire\Livewire::mount('myormawa', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('Y0h12EN', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-md" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myormawainput', [])->dom;
} elseif ($_instance->childHasBeenRendered('ZL7WDHU')) {
    $componentId = $_instance->getRenderedChildComponentId('ZL7WDHU');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZL7WDHU');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZL7WDHU');
} else {
    $response = \Livewire\Livewire::mount('myormawainput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('ZL7WDHU', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>


    <?php elseif($komponen=="myprestasi"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myprestasi', [])->dom;
} elseif ($_instance->childHasBeenRendered('tCmQfT8')) {
    $componentId = $_instance->getRenderedChildComponentId('tCmQfT8');
    $componentTag = $_instance->getRenderedChildComponentTagName('tCmQfT8');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tCmQfT8');
} else {
    $response = \Livewire\Livewire::mount('myprestasi', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('tCmQfT8', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-md" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myprestasiinput', [])->dom;
} elseif ($_instance->childHasBeenRendered('QSPk6Y8')) {
    $componentId = $_instance->getRenderedChildComponentId('QSPk6Y8');
    $componentTag = $_instance->getRenderedChildComponentTagName('QSPk6Y8');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QSPk6Y8');
} else {
    $response = \Livewire\Livewire::mount('myprestasiinput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('QSPk6Y8', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>

    <?php elseif($komponen=="myorangtua"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myorangtua', [])->dom;
} elseif ($_instance->childHasBeenRendered('A2qFKLN')) {
    $componentId = $_instance->getRenderedChildComponentId('A2qFKLN');
    $componentTag = $_instance->getRenderedChildComponentTagName('A2qFKLN');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('A2qFKLN');
} else {
    $response = \Livewire\Livewire::mount('myorangtua', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('A2qFKLN', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-xl" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('myorangtuainput', [])->dom;
} elseif ($_instance->childHasBeenRendered('4cBhBPG')) {
    $componentId = $_instance->getRenderedChildComponentId('4cBhBPG');
    $componentTag = $_instance->getRenderedChildComponentTagName('4cBhBPG');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4cBhBPG');
} else {
    $response = \Livewire\Livewire::mount('myorangtuainput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('4cBhBPG', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>

    <?php elseif($komponen=="mysaudara"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mysaudara', [])->dom;
} elseif ($_instance->childHasBeenRendered('JiVo57d')) {
    $componentId = $_instance->getRenderedChildComponentId('JiVo57d');
    $componentTag = $_instance->getRenderedChildComponentTagName('JiVo57d');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JiVo57d');
} else {
    $response = \Livewire\Livewire::mount('mysaudara', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('JiVo57d', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-md" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mysaudarainput', [])->dom;
} elseif ($_instance->childHasBeenRendered('ZfCLF53')) {
    $componentId = $_instance->getRenderedChildComponentId('ZfCLF53');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZfCLF53');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZfCLF53');
} else {
    $response = \Livewire\Livewire::mount('mysaudarainput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('ZfCLF53', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>

    <?php elseif($komponen=="masterkriteria"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('rekomendasi.masterkriteria', [])->dom;
} elseif ($_instance->childHasBeenRendered('KztJGik')) {
    $componentId = $_instance->getRenderedChildComponentId('KztJGik');
    $componentTag = $_instance->getRenderedChildComponentTagName('KztJGik');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KztJGik');
} else {
    $response = \Livewire\Livewire::mount('rekomendasi.masterkriteria', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('KztJGik', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-xl" id="modalInput" tabindex="-1" role="dialog" aria-labelledby="modalInputLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('rekomendasi.masterkriteriainput', [])->dom;
} elseif ($_instance->childHasBeenRendered('33osTU5')) {
    $componentId = $_instance->getRenderedChildComponentId('33osTU5');
    $componentTag = $_instance->getRenderedChildComponentTagName('33osTU5');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('33osTU5');
} else {
    $response = \Livewire\Livewire::mount('rekomendasi.masterkriteriainput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('33osTU5', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
    </div>






    <?php elseif($komponen=="masterAdminDosen"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('master.admindosen', [])->dom;
} elseif ($_instance->childHasBeenRendered('3mk9JMY')) {
    $componentId = $_instance->getRenderedChildComponentId('3mk9JMY');
    $componentTag = $_instance->getRenderedChildComponentTagName('3mk9JMY');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3mk9JMY');
} else {
    $response = \Livewire\Livewire::mount('master.admindosen', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('3mk9JMY', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    <!-- Modal -->
    
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('master.admindoseninput', [])->dom;
} elseif ($_instance->childHasBeenRendered('mmeHqQO')) {
    $componentId = $_instance->getRenderedChildComponentId('mmeHqQO');
    $componentTag = $_instance->getRenderedChildComponentTagName('mmeHqQO');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mmeHqQO');
} else {
    $response = \Livewire\Livewire::mount('master.admindoseninput', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('mmeHqQO', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

    
    
    <?php elseif($komponen=="masterMatakuliah"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('master.mastermatakuliah', [])->dom;
} elseif ($_instance->childHasBeenRendered('gYvFNGm')) {
    $componentId = $_instance->getRenderedChildComponentId('gYvFNGm');
    $componentTag = $_instance->getRenderedChildComponentTagName('gYvFNGm');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gYvFNGm');
} else {
    $response = \Livewire\Livewire::mount('master.mastermatakuliah', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('gYvFNGm', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
    






    <?php elseif($komponen=="mahasiswaPA"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mahasiswa.mahasiswapa', [])->dom;
} elseif ($_instance->childHasBeenRendered('RzSS5mP')) {
    $componentId = $_instance->getRenderedChildComponentId('RzSS5mP');
    $componentTag = $_instance->getRenderedChildComponentTagName('RzSS5mP');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RzSS5mP');
} else {
    $response = \Livewire\Livewire::mount('mahasiswa.mahasiswapa', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('RzSS5mP', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>


    <?php elseif($komponen=="mahasiswaall"): ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mahasiswa.all', [])->dom;
} elseif ($_instance->childHasBeenRendered('dR44KCX')) {
    $componentId = $_instance->getRenderedChildComponentId('dR44KCX');
    $componentTag = $_instance->getRenderedChildComponentTagName('dR44KCX');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dR44KCX');
} else {
    $response = \Livewire\Livewire::mount('mahasiswa.all', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('dR44KCX', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>









    <?php endif; ?>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('style-halaman'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-halaman'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>




    
    
    <script>
      window.livewire.on('swalAdded', counter => {
        Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            onOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            },
            icon: 'success',
            title: 'Berhasil' ,
            text: 'berhasil menambahkan '+counter+' data!',
        });
        $('#modalInput').modal('hide');
      })

      window.livewire.on('swalUpdated', () => {
        Swal.fire({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 2000,
          //timerProgressBar: true,
          onOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          },
            icon: 'success',
            title: 'Berhasil' ,
            text: 'data telah diubah!',
            confirmButtonText: 'Oke',
        });
        $('#modalInput').modal('hide');
      })

      window.livewire.on('swalDeleted', (tujuan,idhapus) => {
        Swal.fire({
          title: 'Anda yakin?',
          text: "Anda akan menghapus data tersebut!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya, hapus!'
        }).then((result) => {
          if (result.value) {

            window.livewire.emit(tujuan,idhapus);

            Swal.fire(
              'Terhapus!',
              'data telah dihapus.',
              'success'
            )

          }
        });
      })



      window.livewire.on('tutupModal', () =>
      {
        $('#modalInput').modal('hide');
      })


      window.livewire.on('swalAndaYakin', (tujuan,idModel,pesan) => {
        Swal.fire({
          title: 'Anda yakin?',
          text: pesan,
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya!'
        }).then((result) => {
          if (result.value) {

            window.livewire.emit(tujuan,idModel);

            Swal.fire(
              'Berhasil!',
              'data telah diupdate.',
              'success'
            )

          }
        });
      })


    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Documents\1SiteKiki\skripsi\resources\views/page/Datamahasiswa/main.blade.php ENDPATH**/ ?>