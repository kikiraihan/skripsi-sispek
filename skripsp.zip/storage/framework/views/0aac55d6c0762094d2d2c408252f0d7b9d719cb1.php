<?php $__env->startSection('content'); ?>


  <div class="card shadow mb-4 overflow-hidden">
      <div class="card-header border-bottom-0 font-weight-bold text-primary ">Organisasi</div>

      <div class="card-body px-0 py-0">
          <?php if($user->mahasiswa->organisasi->isEmpty()): ?>
          <div class="text-center  mt-5 mb-5">
            <img class="w-50 d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/startup_.svg')); ?>" alt="logout">
            <h5>Organisasi</h5>
            <span class="text-secondary">belum ada data ormawa yang di ikuti</span>
            <br><br>
          </div>
          <?php else: ?>
              <div class="table-responsive">
                  <table class="table table-striped mb-0">
                      <thead class="text-capitalize">
                      <tr>
                          <th>Nama</th>
                          <th>Binaan</th>
                          
                          <th>Website</th>
                          <th>Jenis</th>
                          <th>Kategori</th>
                          <th>Aksi</th>
                      </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $user->mahasiswa->organisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ormawa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td><?php echo e($ormawa->nama); ?></td>
                          <td><?php echo e($ormawa->binaan); ?></td>
                          
                          <td><?php echo e($ormawa->website); ?></td>
                          <td><?php echo e($ormawa->jenis); ?></td>
                          <td><?php echo e($ormawa->kategori); ?></td>
                          <td><a href="#"><i class="icon-plus text-muted"></i>add</a></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
          <?php endif; ?>


      </div>

      <a href="#" class="btn btn-block btn-light rounded-0">Baru <i class="fas fa-plus "></i></a>
  </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('style-halaman'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-halaman'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kiki/1Sites/skripsi/resources/views/page/Datamahasiswa/myormawa.blade.php ENDPATH**/ ?>