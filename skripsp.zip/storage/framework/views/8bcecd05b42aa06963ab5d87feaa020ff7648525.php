<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <form action="<?php echo e(route('posthtml')); ?>" method="POST"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="inihtml">
    <input type="submit" value="kirim">
    </form>

</body>
</html><?php /**PATH /home/kiki/1Sites/skripsi/resources/views/testkiki/upload-html.blade.php ENDPATH**/ ?>