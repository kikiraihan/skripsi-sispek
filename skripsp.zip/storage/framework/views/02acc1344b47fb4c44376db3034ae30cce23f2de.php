<?php $__env->startSection('content'); ?>


  <div class="card shadow mb-4 overflow-hidden">
      <div class="card-header border-bottom-0 font-weight-bold text-primary ">Prestasi</div>

      <div class="card-body px-0 py-0">
          <?php if($user->mahasiswa->prestasi->isEmpty()): ?>
          <div class="text-center  mt-5 mb-5">
            <img class="w-50 d-block p-3 mr-auto ml-auto" src="<?php echo e(asset('ilustrasi/achievement_.svg')); ?>" alt="logout">
            <h5>Prestasi</h5>
            <span class="text-secondary">belum ada data prestasi</span>
            <br><br>
          </div>
          <?php else: ?>
              <div class="table-responsive">
                  <table class="table table-striped mb-0">
                      <thead class="text-capitalize">
                        <tr>
                            <th>judul</th>
                            <th>tanggal</th>
                            <th>tingkat</th>
                            <th>peringkat</th>
                            <th>lokasi</th>
                            <th>kategori</th>
                            <th>Sertifikat</th>
                            <th>status</th>
                            <th>aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $user->mahasiswa->prestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($p->judul); ?></td>
                            <td><?php echo e($p->tanggal->formatLocalized("%d %B %Y")); ?>, <span class="small"><?php echo e($p->tanggal->diffForHumans()); ?></span></td>
                            <td><?php echo e($p->tingkat); ?></td>
                            <td><?php echo e($p->peringkat); ?></td>
                            <td><?php echo e($p->lokasi); ?></td>
                            <td><?php echo e($p->kategori); ?></td>
                            <td><?php echo e($p->Sertifikat); ?></td>
                            <td><?php echo e($p->status); ?></td>
                            <td><a href="#"><i class="icon-plus text-muted"></i>add</a></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
          <?php endif; ?>


      </div>

      <a href="#" class="btn btn-block btn-light rounded-0">Baru <i class="fas fa-plus "></i></a>
  </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('style-halaman'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-halaman'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kiki/1Sites/skripsi/resources/views/page/Datamahasiswa/myprestasi.blade.php ENDPATH**/ ?>